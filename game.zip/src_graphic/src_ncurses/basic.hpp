/*
** EPITECH PROJECT, 2023
** B-OOP-400-PAR-4-1-arcade-titien.carellas
** File description:
** basic.hpp
*/

#ifndef NCURSE_HPP_
	#define NCURSE_HPP_

#include  "../IGraphic.hpp"
#include  <ncurses.h>

class Ncurses : public IGraphic {
	public:
		Ncurses();
		~Ncurses();
		virtual void init();
		virtual void load_assets(std::vector<std::tuple<char, std::string, int>> asset_toload);
		virtual void display_asset(std::vector<std::tuple<char, Position>> object_to_display);
		virtual void debug_print();
		virtual int get_index_tuple(char name);
		virtual int get_key();
		virtual void display_text(std::vector<std::tuple<std::string, Position>> text_to_display);
		virtual void load_text(std::vector<std::tuple<std::string, Position>> text_toload);
		virtual void deleteAssets();
		virtual int display_menu(int choice, int isRunning);
		virtual void load_menu(std::vector<std::string> &menu_toload);
		virtual void display_high_score(std::vector<std::string>high_score);
		void display(int y, int x, std::string str);
		void display(int y, int x, char c);
		void display(Position pos, std::string str);
		void display(Position pos, char c);
		int get_screen_y();
		int get_screen_x();
		void window_refresh();
		void window_clear();
		void display_separation_x(int nb_separation);
		void display_separation_y(int nb_separation);
		std::vector<Position> set_text_pos();
		virtual void displayConfig(size_t _menuChoice, std::vector<std::tuple<std::string, std::vector<size_t>, size_t>> _options);
		virtual void load_config(std::vector<std::tuple<std::string, std::vector<size_t>, size_t>> _options);
	protected:
	private:
	bool _active;
	std::map<std::string, std::pair<char, char>> _rects;
	int _x_screen;
	int _y_screen;
};

#endif /*BASIC_HPP_*/