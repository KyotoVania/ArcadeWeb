/*
** EPITECH PROJECT, 2023
** B-OOP-400-PAR-4-1-arcade-titien.carellas
** File description:
** basic.cpp
*/

#include "basic.hpp"
#include <curses.h>
#include <ncurses.h>

#define RECT_SIZE Ncurses::get_screen_x() / 1.5 / 20 / 1.5
#define OFFSET_X (Ncurses::get_screen_x() - (20 * RECT_SIZE) )/ 2
#define OFFSET_Y Ncurses::get_screen_y() / 4

extern "C" IGraphic *createGraphicInstance()
{
    return new Ncurses();
}

extern "C" std::string getName()
{
    return "ncurses";
}

extern "C" void destroy(IGraphic *graphic)
{
    delete graphic;
}

Ncurses::Ncurses()
{
    _active = false;
    init();
}

Ncurses::~Ncurses()
{
    Ncurses::window_clear();
    _active = false;
    curs_set(TRUE);
    endwin();
}

void Ncurses::debug_print()
{
    std::cout << "debug_print" << std::endl;
}

void Ncurses::init()
{
	initscr();
    cbreak();
    noecho();
    curs_set(0);
    nodelay(stdscr, true);
	halfdelay(1);
    _active = true;
    getmaxyx(stdscr, _y_screen, _x_screen);
	keypad(stdscr, TRUE);
    mousemask(ALL_MOUSE_EVENTS, NULL);
	mouseinterval(0);
}

void Ncurses::load_assets(std::vector<std::tuple<char, std::string, int>> asset_toload)
{
    (void)asset_toload;
    //void the function
    return;
}

void Ncurses::display_asset(std::vector<std::tuple<char, Position>> object_to_display)
{
    Position base_coord(get_screen_x() / 2 - 10, get_screen_y() / 2 - 9);
	window_clear();
    for (auto& object : object_to_display) {
        Position new_pos(std::get<1>(object).getX() + base_coord.getX(), std::get<1>(object).getY() + base_coord.getY());
        display(new_pos, std::string(1, std::get<0>(object)));
    }
    return;
}

int Ncurses::get_index_tuple(char name)
{
    //void the function
    (void)name;
    return 0;
    
}

int Ncurses::get_key()
{
    int key = getch();
	if (key == KEY_UP)
        return 73;
	if (key == KEY_DOWN)
	    return 74;
	if (key == 122)
		return 25;
	if (key == 115)
		return 18; 
    if (key == 113)
        return 16;
    if (key == 100)
        return 3;
    if (key == 261)
        return 72;
    if (key == 260)
        return 71;
    if (key == 27)
        return 36;
    if (key == 10)
        return 58;
    return -1;
}

std::vector<Position> Ncurses::set_text_pos()
{
    Position score_pos(Ncurses::get_screen_x() / 2 - 5, 5);
    Position high_score_pos(Ncurses::get_screen_x() / 2 + 10, 5);
    Position level_pos(Ncurses::get_screen_x() / 2 + 10, 10);
    Position time_pos(Ncurses::get_screen_x() / 2 - 5, 10);
    std::vector<Position> text_pos;

    text_pos.push_back(time_pos);
    text_pos.push_back(score_pos);
    text_pos.push_back(high_score_pos);
    text_pos.push_back(level_pos);
    return (text_pos);
}

void Ncurses::display_text(std::vector<std::tuple<std::string, Position>> text_to_display)
{
    int index = 0;
    std::vector<Position> text_pos = set_text_pos();
    
	for (auto &text_args : text_to_display) {
		display(text_pos[index].getY(), text_pos[index].getX() - std::get<0>(text_args).size(), std::get<0>(text_args));
	    index += 1;
    }
    Ncurses::window_refresh();
    return;
}

void Ncurses::deleteAssets()
{
	    //void the function
    return;
}

void Ncurses::load_text(std::vector<std::tuple<std::string, Position>> text_toload)
{
    (void)text_toload;
    //void the function
    return;
}

int Ncurses::display_menu(int choice, int state)
{
    Position Nibbler_pos(get_screen_x() / 6 - std::string("NIBBLER").size() / 2, get_screen_y() /2);
    Position Snake_pos(get_screen_x() / 2 - std::string(" SNAKE").size() / 2, get_screen_y() /2);
    Position Configs_pos(get_screen_x() / 6 * 5 - std::string("CONFIGS").size() / 2, get_screen_y() /2);

    Ncurses::window_clear();
    if (state == 1)
        return 2;
    display_separation_x(3);
    display(Nibbler_pos, "NIBBLER");
    display(Snake_pos, "SNAKE");
    display(Configs_pos, "CONFIGS");
   	if (choice == 0)
       display(Nibbler_pos.getY(), Nibbler_pos.getX() - 2, ">");
	else if (choice == 1)
   		display(Snake_pos.getY(), Snake_pos.getX() - 2, ">");
	else
    	display(Configs_pos.getY(), Configs_pos.getX() - 2, ">");
	window_refresh();
    return 0;
}

void Ncurses::load_menu(std::vector<std::string> &_possibleGame)
{	
    (void)_possibleGame;
    //void the function
    return;
}

void Ncurses::display_high_score(std::vector<std::string>high_score)
{
	int index = 0;

	Ncurses::window_clear();
	for (auto &i : high_score) {
		Ncurses::display(get_screen_y() / 4 + (index * 3), get_screen_x() / 2 -  i.size() / 2, i);
	    index++;
	}
	Ncurses::window_refresh();
    return;
}

void Ncurses::display(int y, int x, std::string str)
{
    for (std::size_t i = 0; i < str.length(); i++)
        mvprintw(y, x  + i, "%c", str[i]);
}

void Ncurses::display(int y, int x, char c)
{
    mvprintw(y, x, "%c", c);
}

void Ncurses::display(Position pos, std::string str)
{
    for (std::size_t i = 0; i < str.length(); i++)
        mvprintw(pos.getY(), pos.getX()  + i, "%c", str[i]);
}

void Ncurses::display(Position pos, char c)
{
    mvprintw(pos.getY(), pos.getX(), "%c", c);
}

int Ncurses::get_screen_y()
{
    return _y_screen;
}

int Ncurses::get_screen_x()
{
    return _x_screen;
}

void Ncurses::window_refresh()
{
    refresh();
}

void Ncurses::window_clear()
{
    clear();
}


void Ncurses::displayConfig(size_t _menuChoice, std::vector<std::tuple<std::string, std::vector<size_t>, size_t>> _options)
{
	std::string Resolution = "RESOLUTION: " + std::to_string(std::get<1>(_options[0])[std::get<2>(_options[0])]);
	std::string Skine = "SKIN: " + std::to_string(std::get<1>(_options[1])[std::get<2>(_options[1])]);
	Position Resolution_pos(get_screen_x() / 2 - Resolution.size() / 2, get_screen_y() / 4);
	Position Skine_pos(get_screen_x() / 2 - Skine.size() / 2, get_screen_y() / 4 * 3);
	window_clear();
	display_separation_y(2);
	display(Resolution_pos, Resolution);
	display(Skine_pos, Skine);
	if (_menuChoice == 0) 
		display(Resolution_pos.getY(), Resolution_pos.getX() - 2, ">");
	else
		display(Skine_pos.getY(), Skine_pos.getX() - 2, ">");
	window_refresh();
}

void Ncurses::load_config(std::vector<std::tuple<std::string, std::vector<size_t>, size_t>> _options)
{
   //void the function
	(void)_options;
    return;
}

void Ncurses::display_separation_x(int nb_separation)
{
    for (int i = 0; i < Ncurses::get_screen_y(); i += 1) {
        Ncurses::display(i, 0, '#');
        Ncurses::display(i, Ncurses::get_screen_x() - 1, '#');
        for (int j = 1; j != nb_separation; j += 1) {
            Ncurses::display(i, Ncurses::get_screen_x() / nb_separation * j - 1, '#');
        }
    }
    for (int i = 1; i < Ncurses::get_screen_x(); i += 1) {
        Ncurses::display(0, i, '#');
        Ncurses::display(Ncurses::get_screen_y() - 1, i, '#');
    }
}

void Ncurses::display_separation_y(int nb_separation)
{
    for (int i = 0; i < Ncurses::get_screen_y(); i += 1) {
        Ncurses::display(i, 0, '#');
        Ncurses::display(i, Ncurses::get_screen_x() - 1, '#');
    }
    for (int i = 1; i < Ncurses::get_screen_x(); i += 1) {
        Ncurses::display(0, i, '#');
        Ncurses::display(Ncurses::get_screen_y() - 1, i, '#');
		for (int j = 1; j != nb_separation; j += 1) {
            Ncurses::display(Ncurses::get_screen_y() / nb_separation * j, i, '#');
        }
    }
}
