/*
** EPITECH PROJECT, 2023
** arcade
** File description:
** basic.cpp
*/
// the objective is to do the same as the src_sfml/basic.cpp but with SDL2

#include <iostream>
#include <stdexcept>
#include "basic.hpp"

extern "C" IGraphic *createGraphicInstance()
{
    return new Sdl2();
}

extern "C" std::string getName()
{
    return "sdl2";
}

extern "C" void destroy(IGraphic *graphic)
{
    delete graphic;
}

Sdl2::Sdl2()
{
    init();
}

std::pair<int, int> Sdl2::getConfigData()
{
    //read congigure/graphicial.conf
    std::ifstream file("configure/graphical.conf");
    std::string line;
    std::string name;
    std::string value;
    std::string::size_type sz;
    int i = 0;
    if (file.is_open()) {
        while (getline(file, line)) {
            name = line.substr(0, line.find(":"));
            value = line.substr(line.find(":") + 1, line.size());
            _configData.push_back(std::pair(name, value));
            i++;
        }
        file.close();
    } else {
        std::cerr << "Error: Unable to open configure/graphical.conf" << std::endl;
        throw std::runtime_error("Error: Unable to open configure/graphical.conf");
    }
    for (auto& asset : _configData) {
        if (std::get<0>(asset) == "Resolution")
            return (std::make_pair(std::stoi(std::get<1>(asset).substr(0, std::get<1>(asset).find(" ")), &sz), std::stoi(std::get<1>(asset).substr(std::get<1>(asset).find(" ") + 1, std::get<1>(asset).size()), &sz)));
    }
    return (std::make_pair(1920, 1080));
}

void Sdl2::init()
{
    std::pair<int, int> resolution = getConfigData();
    _active = true;
    SDL_DisplayMode DM;
    SDL_Init(SDL_INIT_VIDEO);
    if(!(IMG_Init(IMG_INIT_PNG) & IMG_INIT_PNG ))
        std::cerr << "sdl2 : init img failed" << std::endl;
    TTF_Init();
    SDL_GetCurrentDisplayMode(0, &DM);
    _window = SDL_CreateWindow("Arcade", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, resolution.first, resolution.second, SDL_WINDOW_SHOWN);
	if (_window == NULL) {
    	std::cerr << "sdl2 : init window failed" << std::endl;
    	throw std::runtime_error("sdl2 : init window failed");
	}
    int _width;
    int _height;
    SDL_GetWindowSize(_window, &_width, &_height);
    _renderer = SDL_CreateRenderer(_window, -1, SDL_RENDERER_ACCELERATED);
     if (_renderer == NULL)
        std::cerr << "sdl2 : init renderer failed" << std::endl;
    _font = TTF_OpenFont("assets/arcade.ttf", 20);
    if (TTF_Init() == -1)
        std::cerr << "sdl2 : init ttf failed" << std::endl;
    //clear the window and set a black background
    windowClear();
    SDL_SetRenderDrawColor(_renderer, 0, 0, 0, 255);
    _frameTime = 1000 / 60;
    _frameStartTime = SDL_GetTicks();
}

void Sdl2::delay_frame() {
    // Get the current time
    Uint32 frameEndTime = SDL_GetTicks();
    // Calculate the time taken for the current frame
    Uint32 frameTime = frameEndTime - _frameStartTime;
    // If the frame was rendered too quickly, delay the program
    if (frameTime < _frameTime) {
        SDL_Delay(_frameTime - frameTime);
    }
    // Record the start time of the next frame
    _frameStartTime = SDL_GetTicks();
}


Sdl2::~Sdl2()
{
    windowClear();
    windowClose();
    SDL_DestroyRenderer(_renderer);
    SDL_DestroyWindow(_window);
    TTF_CloseFont(_font);
    TTF_Quit();
    IMG_Quit();
    SDL_Quit();
}


int Sdl2::get_rect_size()
{
    int windowWidth = 0;
    SDL_GetWindowSize(_window, &windowWidth, NULL);
 //   SDL_GetWindowSize(_window, &windowWidth, &windowHeight);
    return windowWidth / 1.5 / 20 / 1.5;
}

int Sdl2::get_offset_x()
{
    int windowWidth;
    int windowHeight;
    SDL_GetWindowSize(_window, &windowWidth, &windowHeight);
    return (windowWidth - (20 * get_rect_size())) / 2;
}

int Sdl2::get_offset_y()
{
    int windowWidth;
    int windowHeight;
    SDL_GetWindowSize(_window, &windowWidth, &windowHeight);
    return windowHeight / 4;
}

int Sdl2::get_cd_size()
{
    int windowWidth;
    int windowHeight;
    SDL_GetWindowSize(_window, &windowWidth, &windowHeight);
    return windowWidth / 7.5;
}

int Sdl2::get_index_tuple(char name) //get the index of the tuple in the vector of tuple
{
    for (std::size_t i = 0; i < _assets.size(); i++) {
        if (std::get<0>(_assets[i]) == name)
            return i;
    }
    return -1;
}

void Sdl2::debug_print() //Print the assets of the game. it will print the assets in the vector of tuple
{
    std::cout << "debug print" << std::endl;
}
void Sdl2::load_assets(std::vector<std::tuple<char, std::string, int>> asset_toload)
{
    SDL_Texture* texture = IMG_LoadTexture(_renderer, "assets/fullRessource.png");
    int index = 0;
    int left = 0;
    int top = 0;

    if (!texture) {
        std::cout << "texture not loaded" << std::endl;
        throw std::exception();
    }

    for (auto& i : asset_toload) {
        index = std::get<2>(i);
        if (index >= 7) {
            top = index / 8 * 8;
            left = index % 8 * 8;
        }
        else {
            top = 0;
            left = index * 8;
        }
        SDL_Rect srcrect = { left, top, 8, 8 };
        _assets.push_back(std::make_tuple(std::get<0>(i), new SDL_Rect(srcrect), texture));
    }
    
}


void Sdl2::load_background_menu(std::string path) //Load the background of the menu. it will store the background in the vector of tuple
{
    SDL_Texture* texture = NULL;
    SDL_Rect rect;
    int _width;
    int _height;
    SDL_GetWindowSize(_window, &_width, &_height);
    rect.w = _width;
    rect.h = _height;
    std::string pathToLoad = "assets/" + path;
    SDL_Surface* surface = IMG_Load(pathToLoad.c_str());
    if (!surface) {
        std::cout << "path : " << pathToLoad << std::endl;
        std::cout << "texture not loaded" << std::endl;
        throw std::exception();
    }
    texture = SDL_CreateTextureFromSurface(_renderer, surface);
    SDL_FreeSurface(surface);
    rect.x = 0;
    rect.y = 0;
    _menu.push_back(std::make_tuple("B", new SDL_Rect(rect), texture));
}

void Sdl2::load_menu(std::vector<std::string> &menu_toload) 
{
    std::vector<std::pair<std::string, std::string>> _possibleAssetPng;
    for (auto &i : menu_toload) {
        _possibleAssetPng.push_back(std::make_pair(i, i + "_CD.png"));
    }
    _possibleAssetPng.push_back(std::make_pair("Config", "Config_CD.png"));
    for (auto &i : _possibleAssetPng) {
        i.second = "assets/" + i.second;
    }
    int width;
    int height;
    SDL_GetWindowSize(_window, &width, &height);
    int part = width / _possibleAssetPng.size();
    std::vector<std::pair<int,int>> _possiblePosition;
    _possiblePosition.push_back(std::make_pair(part / 2 /2, height / 2 - get_cd_size()));
    _possiblePosition.push_back(std::make_pair(width / 2 - get_cd_size() / 2, height / 2 - get_cd_size()));
    _possiblePosition.push_back(std::make_pair(part * 2.75  - get_cd_size(), height / 2 - get_cd_size()));
    _menu_y = _possiblePosition[0].second;
    SDL_Texture* texture = NULL;
    SDL_Rect rect = { 0, 0, get_cd_size(), get_cd_size() };
    int index = 0;
    //create a random texture and rect to test the loading
    for(auto &i : _possibleAssetPng) {
        texture = IMG_LoadTexture(_renderer, i.second.c_str());
        if (!texture) {
            std::cout << "path : " << i.second << std::endl;
            std::cout << "texture not loaded" << std::endl;
            throw std::exception();
        }
        //set the texture to the rect
        rect.x = _possiblePosition[index].first;
        rect.y = _possiblePosition[index].second;
        _menu.push_back(std::make_tuple(i.first, new SDL_Rect(rect), texture));
        index++;
    }
    load_background_menu("background_menu.png");

}
int Sdl2::display_menu(int choice, int state) //Display the menu
{
    //clear the window
    SDL_RenderClear(_renderer);
    int index = 0;
    float rotationSpeed = 360.0f; // degrees per second
    float targetDuration = 1.4f; // seconds
    float targetFrameRate = 60.0f; // frames per second
    float rotationIncrement = rotationSpeed  / (targetFrameRate * targetDuration);
    static std::vector<float> angles(_menu.size(), 0.0f);
    
    for (auto &i : _menu) {
        if (std::get<0>(i) == "B") {
            SDL_RenderSetScale(_renderer, 1, 1);
            SDL_RenderCopy(_renderer, std::get<2>(i), NULL, std::get<1>(i));
        }
    }

    int t = 0;
    for (auto &i : _menu)
    {
        if (std::get<0>(i) == "B")
            continue;
        t++;
        int offsetX = 0;
        int offsetY = 0;

        if (index == choice)
        {
            //we wont change the scale anymore bc to borring to handle so just add a little bit of off set in y
            offsetY = 10;
            offsetX = 10;
            
        }
        else
        {
            SDL_RenderSetScale(_renderer, 1, 1);
            angles[index] = 0;
        }

        if (index == choice && state == 1) {
            angles[index] = fmod(angles[index] + rotationIncrement, 360.0f);
            if (angles[index] >= 359.0f) {
                state = 2;
            }
        }

        SDL_Point center = {std::get<1>(i)->w / 2, std::get<1>(i)->h / 2};
        SDL_Rect dstrect = {std::get<1>(i)->x - offsetX, std::get<1>(i)->y - offsetY, std::get<1>(i)->w, std::get<1>(i)->h};
        SDL_RenderCopyEx(_renderer, std::get<2>(i), NULL, &dstrect, angles[index], &center, SDL_FLIP_NONE);
        index++;
    }

    SDL_RenderPresent(_renderer);
    delay_frame();

    return state;
}






void Sdl2::load_text(std::vector<std::tuple<std::string, Position>> text_toload) //load text objects
//test_toload is a vector of tuples containing(text string, position)
{
    TTF_Font *font = TTF_OpenFont("assets/font.ttf", 20);
    if (!font) {
        std::cout << "font not loaded" << std::endl;
        throw std::exception();
    }
    SDL_Color color = { 255, 255, 255, 255 };
    SDL_Surface* surface = NULL;
    SDL_Texture* texture = NULL;
    for (auto &i : text_toload) {
        surface = TTF_RenderText_Solid(font, std::get<0>(i).c_str(), color);
        if (!surface) {
            std::cout << "surface not loaded" << std::endl;
            throw std::exception();
        }
        texture = SDL_CreateTextureFromSurface(_renderer, surface);
        if (!texture) {
            std::cout << "texture not loaded" << std::endl;
            throw std::exception();
        }
        _text.push_back(std::make_tuple(std::get<0>(i), std::get<1>(i), texture));
        SDL_FreeSurface(surface);
    }
}

void Sdl2::display_asset(std::vector<std::tuple<char, Position>> object_to_display) {
    SDL_RenderClear(_renderer);
    int mult = get_rect_size();
    Position pos_tmp;
    direction_t dir_tmp;
    SDL_Rect rect = { 0, 0, get_rect_size(), get_rect_size() };
    SDL_RenderSetScale(_renderer, 1, 1);
    for (auto &i : object_to_display) {
        if (std::get<0>(i) == '?')
            continue;

        bool asset_found = false;
        SDL_Rect *matched_src_rect = nullptr;
        SDL_Texture *matched_texture = nullptr;

        for (auto &j : _assets) {
            if (std::get<0>(i) == std::get<0>(j)) {
                pos_tmp = std::get<1>(i);
                rect.x = (pos_tmp._x * mult) + get_offset_x();
                rect.y = (pos_tmp._y * mult) + get_offset_y();
                dir_tmp = pos_tmp.getRotation();
                // Debug print statement
                //std::cout << "Asset: " << std::get<0>(i) << " Position: (" << pos_tmp._x << ", " << pos_tmp._y << ")\n";

                matched_src_rect = std::get<1>(j);
                matched_texture = std::get<2>(j);

                asset_found = true;
                break;
            }
        }

        if (asset_found) {
            double angle;
            switch (dir_tmp) {
            case direction_t::UP:
                angle = 0.0;
                break;
            case direction_t::DOWN:
                angle = 180.0;
                break;
            case direction_t::LEFT:
                angle = 270.0;
                break;
            case direction_t::RIGHT:
                angle = 90.0;
                break;
            default:
                angle = 0.0;
                break;
            }

            SDL_Point center = {rect.w / 2, rect.h / 2};
            SDL_RenderCopyEx(_renderer, matched_texture, matched_src_rect, &rect, angle, &center, SDL_FLIP_NONE);
        }
    }
}



void Sdl2::display_text(std::vector<std::tuple<std::string, Position>> text_to_display)
{
    TTF_Font* font = TTF_OpenFont("assets/font.ttf", 24);
    if (!font) {
        std::cout << "font not loaded" << std::endl;
        throw std::exception();
    }
    for (auto& text_args : text_to_display) { //i
        for (auto& text_class : _text) { //j
            //comp only the 3 first char of the string 
            if (std::get<0>(text_args).substr(0, 3) == std::get<0>(text_class).substr(0, 3)) {
                std::get<1>(text_class).setX(std::get<1>(text_args).getX() + get_offset_x() * 2 );
                std::get<1>(text_class).setY(std::get<1>(text_args).getY()/2 + get_offset_y()/2);
                SDL_Color textColor = { 255, 255, 255, 255 };
                SDL_Surface* textSurface = TTF_RenderText_Solid(font, std::get<0>(text_args).c_str(), textColor);
                SDL_Texture* texture = SDL_CreateTextureFromSurface(_renderer, textSurface);
                SDL_FreeSurface(textSurface);

                SDL_Rect rect = { std::get<1>(text_class).getX()/2, std::get<1>(text_class).getY(), 0, 0 };
                SDL_QueryTexture(texture, NULL, NULL, &rect.w, &rect.h);

                SDL_RenderCopy(_renderer, texture, NULL, &rect);

                SDL_DestroyTexture(texture);
            }
        }
    }

    TTF_CloseFont(font);
    SDL_RenderPresent(_renderer);
}

void Sdl2::display_high_score(std::vector<std::string> HighScore)
{
    SDL_SetRenderDrawColor(_renderer, 0, 0, 0, 255);
    SDL_RenderClear(_renderer);
    
    TTF_Font* font = TTF_OpenFont("assets/font.ttf", 48);
    if (!font) {
        std::cout << "font not loaded" << std::endl;
        throw std::exception();
    }
    SDL_Surface* surface = NULL;
    SDL_Texture* texture = NULL;
    SDL_Rect rect;
    rect.x = get_offset_x();
    rect.y = get_offset_y();
    rect.w = 0;
    rect.h = 0;
    int index = 0;
    for (auto &i : HighScore) {
        surface = TTF_RenderText_Solid(font, i.c_str(), {255, 255, 255, 255});
        if (!surface) {
            std::cout << "text surface not created" << std::endl;
            throw std::exception();
        }
        texture = SDL_CreateTextureFromSurface(_renderer, surface);
        if (!texture) {
            std::cout << "texture not created" << std::endl;
            throw std::exception();
        }
        SDL_QueryTexture(texture, NULL, NULL, &rect.w, &rect.h);
        rect.y = get_offset_y() + (index * 50);
        SDL_RenderCopy(_renderer, texture, NULL, &rect);
        SDL_FreeSurface(surface);
        SDL_DestroyTexture(texture);
        index++;
    }
    TTF_CloseFont(font);
    SDL_RenderPresent(_renderer);
}

size_t Sdl2::convert_key(int key)
{
    if (key == SDLK_UP)
        return 73;
    if (key == SDLK_DOWN)
        return 74;
    if (key == SDLK_LEFT)
        return 71;
    if (key == SDLK_RIGHT)
        return 72;
    if (key == SDLK_ESCAPE)
        return 36;
    if (key == SDLK_RETURN)
        return 58;
    if (key == 113)
        return 16;
    if (key == 115)
        return 18;
    if (key == 100)
        return 3;
    if (key == 122)
        return 25;
    return 7;
}


int Sdl2::get_key() //Get the key pressed by the user.
//returns the key pressed by the user
{
    //create an event
    SDL_Event event;
    //get the event in a loop
    while (SDL_PollEvent(&event))
    {
        //if the event is a key pressed
        if (event.type == SDL_KEYDOWN)
        {
            //return the key pressed
            return convert_key(event.key.keysym.sym);
        }
        if (event.type == SDL_QUIT)
            return 36;
    }
    return -1;
}

void Sdl2::windowClear() //Clear the window.
{
    //clear the window
    SDL_SetRenderDrawColor(_renderer, 0, 0, 0, 0);
    SDL_RenderClear(_renderer);
}

void Sdl2::windowClose() //Close the window
{
    _active = false;
}

void Sdl2::deleteAssets()
{
}

void Sdl2::load_config(std::vector<std::tuple<std::string, std::vector<size_t>, size_t>> _options)
{
    TTF_Font* font = TTF_OpenFont("assets/font.ttf", 48);
    if (!font) {
        std::cout << "font not loaded" << std::endl;
        throw std::exception();
    }
    SDL_Color color = { 255, 255, 255, 255 };
    SDL_Surface* surface = NULL;
    SDL_Texture* texture = NULL;
    std::string name;
    std::string val;

    for (auto &i : _options) {
        name = std::get<0>(i);
        val = std::to_string(std::get<1>(i)[std::get<2>(i)]);
        surface = TTF_RenderText_Solid(font, (name + " : " + val).c_str(), color);

        if (!surface) {
            std::cout << "surface not loaded" << std::endl;
            throw std::exception();
        }

        texture = SDL_CreateTextureFromSurface(_renderer, surface);
        SDL_FreeSurface(surface);

        _optionsText.push_back(std::make_tuple(name, val, texture));
    }
}

void Sdl2::displayConfig(size_t _menuChoice, std::vector<std::tuple<std::string, std::vector<size_t>, size_t>> _options)
{
    SDL_RenderClear(_renderer);
    SDL_Rect rect;
    rect.w = 0;
    rect.h = 48;
    
    for (size_t i = 0; i < _optionsText.size(); i++) {
        std::get<1>(_optionsText[i]) = std::get<0>(_optionsText[i]) + " : " + std::to_string(std::get<1>(_options[i])[std::get<2>(_options[i])]);
        rect.x = 50;
        rect.y = 50 + (i * 100);
        std::get<2>(_optionsText[i]) = SDL_CreateTextureFromSurface(_renderer, TTF_RenderText_Solid(TTF_OpenFont("assets/font.ttf", 48), std::get<1>(_optionsText[i]).c_str(), { 255, 255, 255, 255 }));
        SDL_QueryTexture(std::get<2>(_optionsText[i]), NULL, NULL, &rect.w, &rect.h);

        if (i == _menuChoice) {
            SDL_SetTextureColorMod(std::get<2>(_optionsText[i]), 255, 0, 0);
        } else {
            SDL_SetTextureColorMod(std::get<2>(_optionsText[i]), 255, 255, 255);
        }
        SDL_RenderCopy(_renderer, std::get<2>(_optionsText[i]), NULL, &rect);
    }
    SDL_RenderPresent(_renderer);
    delay_frame();

}
