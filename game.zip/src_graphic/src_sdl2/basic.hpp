/*
** EPITECH PROJECT, 2023
** B-OOP-400-PAR-4-1-arcade-titien.carellas
** File description:
** basic.hpp
*/
#ifndef SDL2_HPP_
    #define SDL2_HPP_

#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_ttf.h>
#include <SDL2/SDL_mixer.h>
#include "../IGraphic.hpp"

class Sdl2 : public IGraphic {
public:
    Sdl2();
    ~Sdl2();
    virtual void init();
    virtual void load_assets(std::vector<std::tuple<char, std::string, int>> asset_toload);
    virtual void display_asset(std::vector<std::tuple<char, Position>> object_to_display);
    virtual void debug_print();
    virtual int get_index_tuple(char name);
    virtual int get_key();
    virtual void display_text(std::vector<std::tuple<std::string, Position>> text_to_display);
    virtual void load_text(std::vector<std::tuple<std::string, Position>> text_toload);
    virtual int display_menu(int choice, int isRunning);
    virtual void load_menu(std::vector<std::string> &menu_toload);
	virtual void deleteAssets();
	virtual void load_config(std::vector<std::tuple<std::string, std::vector<size_t>, size_t>> _options);
    virtual void display_high_score(std::vector<std::string> high_score);
    virtual void displayConfig(size_t _menuChoice, std::vector<std::tuple<std::string, std::vector<size_t>, size_t>> _options);
	void load_background_menu(std::string path);
	void windowClear();
	void windowClose();
	int get_rect_size();
	int get_offset_x();
	int get_offset_y();
	int get_cd_size();
	size_t convert_key(int key);
	void delay_frame();
	std::pair<int, int> getConfigData();

private:
	bool _active;
    SDL_Window* _window;
    SDL_Renderer* _renderer;
    std::vector<std::tuple<char, SDL_Rect *, SDL_Texture*>> _assets;
    std::vector<std::tuple<std::string, Position, SDL_Texture*>> _text;
    std::vector<std::tuple<std::string, SDL_Rect *, SDL_Texture*>> _menu;
	std::vector<std::tuple<std::string, Position, std::string>> _string;
	//do like  	std::vector<std::tuple<std::string, std::string, sf::Text *>> _optionsText; but for sdl
	std::vector<std::tuple<std::string, std::string, SDL_Texture*>> _optionsText;
	std::vector<std::pair<std::string, std::string>> _configData;

    SDL_Texture* _background;
    int _key;
	int _menu_y = 0;
    TTF_Font* _font;
	Uint32 _frameStartTime;
	Uint32 _frameTime;
};
#endif /* !sdl2_HPP_ */