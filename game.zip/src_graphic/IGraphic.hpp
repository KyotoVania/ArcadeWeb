/**
 * \file IGraphic.hpp
 * \brief Header file for the IGraphic interface
 * \author Titien Carellas
 * \version 1.0
 * \date 2023-04-03
 *
 * This file defines the IGraphic interface that provides the necessary functions for
 * loading, displaying, and handling game assets.
 */

#ifndef BASE_GRAPHIC_HPP_
#define BASE_GRAPHIC_HPP_

#include <iostream>
#include <string>
#include <vector>
#include <tuple>
#include <map>
#include <fstream>
#include "../shared/Position.hpp"

/**
 * \class IGraphic
 * \brief Interface for handling game assets
 *
 * IGraphic provides an interface for loading, displaying, and managing
 * game assets such as images, text, and menus.
 */
class IGraphic {
    public:
        virtual ~IGraphic() = default;
         /**
         * \brief Display text objects
         * \param text_to_display Vector of tuples containing (text string, position)
         */
        virtual void display_text(std::vector<std::tuple<std::string, Position>> text_to_display) = 0;

        /**
         * \brief Get the index of a tuple by identifier character
         * \param name Identifier character of the tuple
         * \return Index of the tuple
         */
        virtual int get_index_tuple(char name) = 0;

        /**
         * \brief Get the pressed key code
         * \return Key code of the pressed key
         */
        virtual int get_key() = 0;

        /**
         * \brief Delete all loaded assets
         */
        virtual void deleteAssets() = 0;

        /**
         * \brief Load text objects
         * \param text_toload Vector of tuples containing (text string, position)
         */
        virtual void load_text(std::vector<std::tuple<std::string, Position>> text_toload) = 0;

        /**
         * \brief Display the menu
         * \param choice Menu choice index
         * \param isRunning Menu running state
         * \return Menu status
         */
        virtual int display_menu(int choice, int isRunning) = 0;

        /**
         * \brief Load the menu
         * \param menu_toload Vector of menu items as strings
         */
        virtual void load_menu(std::vector<std::string> &menu_toload) = 0;

        /**
         * \brief Display the high scores
         * \param high_score Vector of high scores as strings
         */
        virtual void display_high_score(std::vector<std::string> high_score) = 0;
        /**
         * \brief Display the configuration menu
         * \param _menuChoice Selected menu choice
         * \param _options Vector of tuples containing (option name, option values, selected value)
         */
        virtual void displayConfig(size_t _menuChoice,std::vector<std::tuple<std::string, std::vector<size_t>, size_t>> _options) = 0;
        /**
         * \brief Load the configuration menu
         * \param _options Vector of tuples containing (option name, option values, selected value)
         */
         virtual void load_config(std::vector<std::tuple<std::string, std::vector<size_t>, size_t>> _options) = 0;
        /**
         *\fn virtual void debug_print() = 0;
         *\brief Debug function to print the loaded assets
         */
        virtual void debug_print() = 0;
        /**
         * \fn virtual void load_assets(std::vector<std::tuple<char, std::string, int>> asset_toload) = 0;
         * \brief Load assets from a vector of tuples
         *  \param asset_toload Vector of tuples containing (identifier character, asset path, asset type)
         */
        virtual void load_assets(std::vector<std::tuple<char, std::string, int>> asset_toload) = 0;
        /**
          * \fn virtual void display_asset(std::vector<std::tuple<char, Position>> object_to_display) = 0;
         * \brief Display assets from a vector of tuples
         * \param object_to_display Vector of tuples containing (identifier character, position)
         */
        virtual void display_asset(std::vector<std::tuple<char, Position>> object_to_display) = 0;


	protected:

	private:
};

#endif /*BASE_GRAPHIC_HPP_*/