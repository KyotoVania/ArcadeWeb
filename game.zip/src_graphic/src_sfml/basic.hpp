/*
** EPITECH PROJECT, 2023
** B-OOP-400-PAR-4-1-arcade-titien.carellas
** File description:
** basic.hpp
*/
#ifndef SFML_HPP_
	#define SFML_HPP_

#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include <SFML/System.hpp>
#include <SFML/Audio.hpp>
#include <SFML/Network.hpp>
#include "../IGraphic.hpp"


class Sfml : public IGraphic {
	public:
		Sfml();
		~Sfml();
		/**
		 * \fn std::pair<int, int> getConfigData();
		 * \brief Get the config data : resolution 
		 * \return std::pair<int, int> : resolution
		 */
		std::pair<int, int> getConfigData();
		/**
		 * \fn virtual void init();
		 * \brief Initialize the window and the music
		 */
		virtual void init();
		/**
		 * \fn virtual void load_assets(std::vector<std::tuple<char, std::string, int>> asset_toload);
		 * \brief Load the assets of the game. it will store the assets in the vector of tuple see \ref _assets for more details
		 * \param asset_toload A vector of tuple containing the character, the path to the asset and the index for the spritesheet
		 */ 
		virtual void load_assets(std::vector<std::tuple<char, std::string, int>> asset_toload);
		/**
		 * \fn virtual void display_asset(std::vector<std::tuple<char, Position>> object_to_display);
		 * \brief Display the assets of the game. it will display the assets in the vector of tuple see \ref _assets for more details. it will receive the position, and the identifier of the asset(character) to display
		 * \param object_to_display A vector of tuple containing the character, the position of the asset
		 */
		virtual void display_asset(std::vector<std::tuple<char, Position>> object_to_display);
		/**
		 * \fn virtual void debug_print();
		 * \brief Print the assets of the game. it will print the assets in the vector of tuple see \ref _assets for more details
		 */
		virtual void debug_print();
		/**
		 * \fn virtual int get_index_tuple(char name);
		 * \brief Get the index of the tuple in the vector of tuple see \ref _assets for more details
		 * \param name The character of the asset
		 * \return The index of the tuple in the vector of tuple see \ref _assets. if the character is not found, it will return -1
		 */
		virtual int get_index_tuple(char name);
		/**
		 * \fn virtual int get_key();
		 * \brief Get the key pressed by the user
		 * \return The key pressed by the user
		 */
		virtual int get_key();
		/**
		 * \fn virtual void display_text(std::vector<std::tuple<std::string, Position>> text_to_display);
		 * \brief Display the text of the game. it will display the text in the vector of tuple see \ref _text.
		 * \param text_to_display A vector of tuple containing the string, the position of the text
		 */
		virtual void display_text(std::vector<std::tuple<std::string, Position>> text_to_display);
		/**
		 * \fn virtual void load_text(std::vector<std::tuple<std::string, Position>> text_toload);
		 * \brief Load the text of the game. it will store the text in the vector of tuple see \ref _text.
		 * \param text_toload A vector of tuple containing the string, the position of the text
		 */
		virtual void load_text(std::vector<std::tuple<std::string, Position>> text_toload);
		/**
		 * \fn virtual int display_menu(int choice, int isRunning);
		 * \brief Display the menu of the game. it will display the menu in the vector of tuple see \ref _menu.
		 * \param choice The choice of the user.
		 */
		virtual int display_menu(int choice, int isRunning);
		/**
		 * \fn virtual void load_menu(std::vector<std::string> &menu_toload);
		 * \brief Load the menu of the game. it will store the menu in the vector of tuple see \ref _menu.
		 * \param menu_toload A vector of string containing the path to the menu.
		 */
		virtual void load_menu(std::vector<std::string> &menu_toload);
		/**
		 * \fn virtual void display_high_score(std::vector<std::string>high_score);
		 * \brief Display the high score of the game. it will display the high score in the vector of string received for the 10 best score.
		 * \param high_score A vector of string containing the high score.
		 */
		virtual void display_high_score(std::vector<std::string>high_score);
		/**
		 * \fn virtual void displayConfig(size_t _menuChoice, std::vector<std::tuple<std::string, std::vector<size_t>, size_t>> _options);
		 * \brief Display the config of the game. it will display the config in the vector of tuple received. Highlighting the choice of the user.
		 * \param _menuChoice The choice of the user.
		 * \param _options A vector of tuple containing the name of the option, a vector of the value of the option and the index of the option.
		*/
		virtual void displayConfig(size_t _menuChoice, std::vector<std::tuple<std::string, std::vector<size_t>, size_t>> _options);
		/**
		 * \fn virtual void load_config(std::vector<std::tuple<std::string, std::vector<size_t>, size_t>> _options);
		 * \brief Load the config of the game. it will store the config in the vector of tuple received.
		 * \param _options A vector of tuple containing the name of the option, a vector of the value of the option and the index of the option.
		*/
		virtual void load_config(std::vector<std::tuple<std::string, std::vector<size_t>, size_t>> _options);
		/**
		 * \fn virtual void deleteAssets();
		 * \brief Delete the assets of the game. it will delete the assets in the vector of tuple see \ref _assets.
		 */
		virtual void deleteAssets();
		/**
		 * \fn virtual void load_background_menu(std::string path);
		 * \brief Load the background of the menu. it will store the background in the vector of tuple see \ref _menu.
		 */
		void load_background_menu(std::string path);
		/**
		 * \fn int isConfirmSoundPlaying();
		 * \brief Check if the confirm sound is playing.
		 * \return 2 if the confirm sound is finished.
		 * \return 1 if the confirm sound is playing.
		 * \return 0 if the confirm sound is not playing.
		 */
		int isConfirmSoundPlaying();
		/**
		 *\fn void reverseMusic(std::string name);
		 *\brief Stop the music and play the music in parameter.
		 *\param name The name of the music to play.
		 */
	    void reverseMusic(std::string name);
	protected:
	/**
	 * \brief Check if the game is active.
	 */
	bool _active;
	/**
	 * \brief A vector of tuple containing the character of the asset, the rectangle shape of the asset and the texture of the asset.
	 */
	std::vector<std::tuple<char, sf::RectangleShape *, sf::Texture>> _assets;
	/**
	 * \brief A vector of tuple containing the string of the text, the position of the text and the text.
	 */
	std::vector<std::tuple<std::string, Position, sf::Text *>> _string;
	/**
	 * \brief A vector of tuple containing the string of the menu, the rectangle shape of the menu and the texture of the menu.
	 */
	std::vector<std::tuple<std::string, sf::RectangleShape *, sf::Texture>> _menu;
	/**
	 * \brief A vector of tuple containing the name of the music, the path of the music and the music.
	 */
	std::vector<std::tuple<std::string, std::string, sf::Music *>> _music;
	/**
	 * \brief A vector of tuple containing the name of the sound, the path of the sound, the sound and the sound buffer.
	 */
	std::vector<std::tuple<std::string, std::string, sf::Sound *, sf::SoundBuffer *>> _sound_menu;
	/**
	 * \brief The window to render in SFML.
	 */
	sf::RenderWindow _window;
	/**
	 * \brief The event of the window.
	 */
	sf::Event _event;
	/**
	 * \brief A vector of pair containing the name of the option and the value of the option.
	 */
	std::vector<std::pair<std::string, std::string>> _configData;
	/**
	 * \brief A vector of tuple containing the name of the option, the value of the option and the text.
	 */
	std::vector<std::tuple<std::string, std::string, sf::Text *>> _optionsText;
private:

};
#endif /* !SFML_HPP_ */