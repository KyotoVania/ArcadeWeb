/*
** EPITECH PROJECT, 2023
** B-OOP-400-PAR-4-1-arcade-titien.carellas
** File description:
** basic.cpp
*/

#include "basic.hpp"

//based on the window size we will add an offset to all the position to center the game 
//the calcul is based on the size of the window its like windowsize/1.5/20 = rectsize 
#define RECT_SIZE _window.getSize().x / 1.5 / 20 / 1.5
#define OFFSET_X (_window.getSize().x - (20 * RECT_SIZE) )/ 2
#define OFFSET_Y _window.getSize().y / 4
#define CD_SIZE _window.getSize().x / 7.5


extern "C" IGraphic *createGraphicInstance()
{
    return new Sfml();
}

extern "C" std::string getName()
{
    return "sfml";
}

extern "C" void destroy(IGraphic *graphic)
{
    delete graphic;
}

Sfml::Sfml()
{
    init();
}

std::pair<int, int> Sfml::getConfigData()
{
    //read congigure/graphicial.conf
    std::ifstream file("configure/graphical.conf");
    std::string line;
    std::string name;
    std::string value;
    std::string::size_type sz;
    int i = 0;

    if (file.is_open()) {
        while (getline(file, line)) {
            name = line.substr(0, line.find(":"));
            value = line.substr(line.find(":") + 1, line.size());
            _configData.push_back(std::pair(name, value));
            i++;
        }
    }
    file.close();
    for (auto& asset : _configData) {
        if (std::get<0>(asset) == "Resolution")
            return (std::make_pair(std::stoi(std::get<1>(asset).substr(0, std::get<1>(asset).find(" ")), &sz), std::stoi(std::get<1>(asset).substr(std::get<1>(asset).find(" ") + 1, std::get<1>(asset).size()), &sz)));
    }
    return (std::make_pair(1920, 1080));
}

void Sfml::init()
{
    //will now read the file to get the last config of the user
    std::pair<int, int> resolution = getConfigData();
    _window.create(sf::VideoMode(resolution.first, resolution.second), "Arcade");
	_window.setFramerateLimit(60);
    _active = true;
    _window.clear(sf::Color::Black);
	_music.push_back(std::make_tuple("mainMenu", "assets/sounds/01.-Main-Menu.ogg", new sf::Music()));	
	_music.push_back(std::make_tuple("game", "assets/sounds/03.-Game-Cave.ogg", new sf::Music()));
	_sound_menu.push_back(std::make_tuple("confirm", "assets/sounds/02-No-Disc-Inserted-Banner.ogg", new sf::Sound(), new sf::SoundBuffer()));
	for (auto& asset : _music) {
        if (std::get<0>(asset) == "mainMenu"){
            if (!std::get<2>(asset)->openFromFile(std::get<1>(asset)))
                std::cout << "error loading music" << std::endl;
            std::get<2>(asset)->play();
        } else {
            if (!std::get<2>(asset)->openFromFile(std::get<1>(asset)))
                std::cout << "error loading music" << std::endl;
            std::get<2>(asset)->setLoop(true);
			std::get<2>(asset)->setVolume(33);
        }
    }

	for (auto& asset : _sound_menu) {
        if (!std::get<3>(asset)->loadFromFile(std::get<1>(asset)))
            std::cout << "error loading sound" << std::endl;
		std::get<2>(asset)->setBuffer(*std::get<3>(asset));
		std::get<2>(asset)->setLoop(false);
		std::get<2>(asset)->setVolume(100);
    }
	
}

Sfml::~Sfml()
{
	for (auto& asset : _music) {
        delete std::get<2>(asset);
    }
    _window.clear();
    _active = false;
    for (auto& asset : _assets) {
        delete std::get<1>(asset);
    }
    std::cout << "window closed SFML" << std::endl;
}

int Sfml::get_index_tuple(char name)
{
    for (std::size_t i = 0; i < _assets.size(); i++) {
        if (std::get<0>(_assets[i]) == name)
            return i;
    }
    return -1;
}

void Sfml::debug_print()
{
    std::cout << "debug_print" << std::endl;
}

void Sfml::load_assets(std::vector<std::tuple<char, std::string, int>> asset_toload)
{
    sf::Texture texture = sf::Texture();
    sf::RectangleShape rect = sf::RectangleShape(sf::Vector2f(RECT_SIZE, RECT_SIZE));
    int index = 0;
    int left = 0;
    int top = 0;
    //create a random texture and rect to test the loading
    if (!texture.loadFromFile("assets/fullRessource.png")) {
        std::cout << "texture not loaded" << std::endl;
        throw std::exception();
    }
    rect.setTexture(&texture);
    rect.setPosition(0, 0);
    _assets.push_back(std::make_tuple('?', new sf::RectangleShape(rect), texture));
    
    for (auto &i : asset_toload) {
        if (get_index_tuple(std::get<0>(i)) == -1) {
            index = std::get<2>(i);
            if (index >= 7) {
                top = index / 8 * 8; //to check but should work index is divided by 10 so we get the row and multiply by 8 to get the top
                left = index % 8 * 8; //same but with the column
            }
            else {
                top = 0;
                left = index * 8;
            }
            rect.setTexture(&texture);
            rect.setTextureRect(sf::IntRect(left, top, 8, 8));
            rect.setPosition(0, 0);
            rect.setOrigin(rect.getSize().x / 2, rect.getSize().y / 2);
            (void)left;
            (void)top;
            //aplly to rect in the IGraphic class
            _assets.push_back(std::make_tuple(std::get<0>(i), new sf::RectangleShape(rect), texture));
        } else if (get_index_tuple(std::get<0>(i)) != -1) {
            index = std::get<2>(i);
            if (index >= 7) {
                top = index / 8 * 8; //to check but should work index is divided by 10 so we get the row and multiply by 8 to get the top
                left = index % 8 * 8; //same but with the column
            }
            else {
                top = 0;
                left = index * 8;
            }
			rect.setTextureRect(sf::IntRect(left, top, 8, 8));
			//check the head of the snake "H" beacuse the behavior is weird 
            rect.setPosition(0, 0);
            rect.setOrigin(rect.getSize().x / 2, rect.getSize().y / 2);
			//replace the old rect with the new one
			_assets[get_index_tuple(std::get<0>(i))] = std::make_tuple(std::get<0>(i), new sf::RectangleShape(rect), texture);
        }
    }
}


void Sfml::load_background_menu(std::string path)
{
    sf::Texture texture = sf::Texture();
    sf::RectangleShape rect = sf::RectangleShape(sf::Vector2f(_window.getSize().x, _window.getSize().y));
    if (!texture.loadFromFile(path)) {
        std::cout << "texture not loaded" << std::endl;
        throw std::exception();
    }
    rect.setTexture(&texture);
    rect.setPosition(0, 0);
	_menu.push_back(std::make_tuple("B", new sf::RectangleShape(rect), texture));
}

void Sfml::load_menu(std::vector<std::string> &_possibleGame)
{
    //for each game in the _possibleGame vector create a sfml rect and load the texture called game + "_CD.png" in assets folder
    std::vector<std::pair<std::string, std::string>> _possibleAssetPng;
    for (auto &i : _possibleGame) {
        _possibleAssetPng.push_back(std::make_pair(i, i + "_CD.png"));
    }
    _possibleAssetPng.push_back(std::make_pair("Config", "Config_CD.png"));
    //we will now divide the screen in 3 part (they dont need to take all the size of the screen a good space of at least 20% of screen size is enough) and load the texture in the middle of each part

    int width = _window.getSize().x;
    int height = _window.getSize().y;
    int part = width / 3;
    std::vector<std::pair <int,int>> _possiblePosition;
    _possiblePosition.push_back(std::make_pair(part / 2, height / 2 - CD_SIZE / 2));
    _possiblePosition.push_back(std::make_pair(part + part / 2, height / 2 - CD_SIZE / 2));
    _possiblePosition.push_back(std::make_pair(part * 2 + part / 2, height / 2 - CD_SIZE / 2));
    sf::Texture texture = sf::Texture();
    sf::RectangleShape rect = sf::RectangleShape(sf::Vector2f(CD_SIZE, CD_SIZE));
    int index = 0;
    rect.setPosition(0, 0);
    for (auto &i : _possibleAssetPng) {
        if (!texture.loadFromFile("assets/" + i.second)) {
            std::cout << "texture not loaded" << std::endl;
            throw std::exception();
        }
        rect.setTexture(&texture);
        rect.setPosition(_possiblePosition[index].first, _possiblePosition[index].second);
        rect.setOrigin(rect.getSize().x / 2, rect.getSize().y / 2);
        _menu.push_back(std::make_tuple(i.first, new sf::RectangleShape(rect), texture));
        index++;
    }

	//create shadow under the texture using the shadow.png in asset it corresponds to the shadow of the cd	
	std::vector<std::tuple<std::string, sf::RectangleShape*, sf::Texture>> shadowMenu;
	for (auto &i : _menu) {
        if (!texture.loadFromFile("assets/shadow.png")) {
            std::cout << "texture not loaded" << std::endl;
            throw std::exception();
        }
        rect.setTexture(&texture);
        rect.setPosition((std::get<1>(i))->getPosition().x, (std::get<1>(i))->getPosition().y + CD_SIZE);
        rect.setOrigin(rect.getSize().x / 2, rect.getSize().y / 2);
        shadowMenu.push_back(std::make_tuple("S", new sf::RectangleShape(rect), texture));
    }
	_menu.insert(_menu.end(), shadowMenu.begin(), shadowMenu.end());
	load_background_menu("assets/background_menu.png");
}

void Sfml::reverseMusic(std::string activMusic)
{

    for (auto &i : _music) {
        if (std::get<0>(i) == activMusic) {
			if (std::get<2>(i)->getStatus() != sf::SoundSource::Status::Playing){
            	std::get<2>(i)->play();
			}
        }
		else{
			std::get<2>(i)->pause();
		}
    }
}

int Sfml::isConfirmSoundPlaying() {
    for (auto &i : _sound_menu) {
        if (std::get<0>(i) == "confirm") {
            if (std::get<2>(i)->getPlayingOffset() > sf::seconds(1.75)){
                std::get<2>(i)->stop();
                return 2;   // return state 2: starting
            }
        }
    }
    return 1; // return state 1: waiting
}


int Sfml::display_menu(int choice, int state) // state: 0 - menu, 1 - waiting, 2 - starting
{
    //display the menu
    reverseMusic("mainMenu");
    _window.clear();
    int index = 0;
    int soundState = state;
    float rotationSpeed = 360.0f; // degrees per second
    float targetDuration = 1.4f; // seconds
	float targetFrameRate = 60.0f; // frames per second
    float rotationIncrement = rotationSpeed  / (targetFrameRate * targetDuration);
    for (auto &i : _menu) {
        if (std::get<0>(i) == "B") {
            std::get<1>(i)->setTexture(&std::get<2>(i));
            _window.draw(*(std::get<1>(i)));
        }
    }
    for (auto &i : _menu) {
        if (std::get<0>(i) == "B")
            continue;
        if (index == choice)//increase thesize of the rect if it is the choice
            (std::get<1>(i))->setScale(1.2, 1.2);
        else //else set the scale to 1
            (std::get<1>(i))->setScale(1, 1);
        if (index == choice && state == 1 && (std::get<1>(i))->getRotation() < 359) {
            for (auto &i : _sound_menu) {
                if (std::get<0>(i) == "confirm" && std::get<2>(i)->getStatus() != sf::Sound::Playing)
                    std::get<2>(i)->play();
            }
            std::get<1>(i)->setRotation((std::get<1>(i))->getRotation() + rotationIncrement);
        }
        if (index == choice && state == 1 && (std::get<1>(i))->getRotation() >= 359) {
            (std::get<1>(i))->setRotation(0);
            soundState = isConfirmSoundPlaying();
            if (soundState != 2) { // if not in state 2: starting
                std::get<1>(i)->setTexture(&std::get<2>(i));
                _window.draw(*std::get<1>(i));
                index++;
                continue;
            } else {
                return 2; // return state 2: starting
            }
        }
        std::get<1>(i)->setTexture(&std::get<2>(i));
        _window.draw(*std::get<1>(i));
        index++;
    }
    _window.display();
    return soundState;
}


void Sfml::load_text(std::vector<std::tuple<std::string, Position>> text_toload)
{
    //create sfml text and load the font and the text
    sf::Font font = sf::Font();
    if (!font.loadFromFile("assets/font.ttf")) {
        std::cout << "font not loaded" << std::endl;
        throw std::exception();
    }
    sf::Text text;
    text.setFont(font);
    text.setCharacterSize(48);
    text.setFillColor(sf::Color::White);
    for (auto &i : text_toload) {
        text.setString(std::get<0>(i));
        text.setPosition(std::get<1>(i).getX() + OFFSET_X, std::get<1>(i).getY() + OFFSET_Y);
        _string.push_back(std::make_tuple(std::get<0>(i), std::get<1>(i), new sf::Text(text)));
    }
}

void Sfml::display_asset(std::vector<std::tuple<char, Position>> object_to_display)
{
    _window.clear(sf::Color::Black);
	reverseMusic("game");
    int mult = RECT_SIZE;
    Position pose_tmp;
    direction_t dir_tmp;
    for (auto &i : object_to_display) {
        if (std::get<0>(i) == '?')
            continue;
        for (auto &j : _assets) {
            if (std::get<0>(i) == std::get<0>(j)) {
                pose_tmp = std::get<1>(i);//the fuck pourquoi cest i et pas j
                std::get<1>(j)->setPosition(pose_tmp.getX() * mult + OFFSET_X, pose_tmp.getY() * mult + OFFSET_Y);
                sf::Vector2f centered = sf::Vector2f(std::get<1>(j)->getLocalBounds().width / 2, std::get<1>(j)->getLocalBounds().height / 2);
                std::get<1>(j)->setPosition(std::get<1>(j)->getPosition() + centered);
                //apply a rotation to the rect if needed
                dir_tmp = std::get<1>(i).getRotation();
                
                if (dir_tmp == direction_t::UP)
                {
                    std::get<1>(j)->setRotation(0);
                }
                else if (dir_tmp == direction_t::DOWN)
                {
                    std::get<1>(j)->setRotation(180);
                }
                else if (dir_tmp == direction_t::LEFT)
                {
                    std::get<1>(j)->setRotation(270);
                }
                else if (dir_tmp == direction_t::RIGHT)
                {
                    std::get<1>(j)->setRotation(90);
                }
                else if (dir_tmp == direction_t::NONE)
                {
                    std::get<1>(j)->setRotation(0);
                    //std::get<1>(j)->setScale(1, 1);
                }
                std::get<1>(j)->setTexture(&std::get<2>(j));
                _window.draw(*std::get<1>(j));
                //draw the bording of std::get<1>(j)
            }
        }
    }
}


void Sfml::display_text(std::vector<std::tuple<std::string, Position>> text_to_display)
{
    sf::Font font;
    if (!font.loadFromFile("assets/font.ttf")) {
        std::cout << "font not loaded" << std::endl;
        throw std::exception();
    }
    
    for (auto &text_args : text_to_display) { //i
        for (auto &text_class : _string) { //j
            //comp only the 3 first char of the string 
            if (std::get<0>(text_args).substr(0, 3) == std::get<0>(text_class).substr(0, 3)) {
                std::get<1>(text_class).setX(std::get<1>(text_args).getX());
                std::get<1>(text_class).setY(std::get<1>(text_args).getY());
                (*std::get<2>(text_class)).setPosition(std::get<1>(text_class).getX(), std::get<1>(text_class).getY());
                (*std::get<2>(text_class)).setString(std::get<0>(text_args));
                (*std::get<2>(text_class)).setFont(font);
                _window.draw((*std::get<2>(text_class)));
            }

        }
    }
    _window.display();
}
//the high score is a vector of string "name:game:score" we will display the 10 best score (the vector should automatically be sorted and 10 element long)
void Sfml::display_high_score(std::vector<std::string> HighScore)
{
	_window.clear(sf::Color::Black);
    sf::Font font;
    if (!font.loadFromFile("assets/font.ttf")) {
        std::cout << "font not loaded" << std::endl;
        throw std::exception();
    }
    sf::Text text;
    text.setFont(font);
    text.setCharacterSize(48);
    text.setFillColor(sf::Color::White);
    int index = 0;
    for (auto &i : HighScore) {
        text.setString(i);
        text.setPosition(OFFSET_X, OFFSET_Y + (index * 50));
        _window.draw(text);
        index++;
    }
    _window.display();
}


void Sfml::load_config(std::vector<std::tuple<std::string, std::vector<size_t>, size_t>> _options)
{

    sf::Text text;
    sf::Font font;
	std::string name;
	std::string val;
    if (!font.loadFromFile("assets/font.ttf"))
        std::cout << "error loading font" << std::endl;
    for (auto &i : _options) {
		name = std::get<0>(i);
        text.setString(name);
		text.setPosition(OFFSET_X, OFFSET_Y + (std::get<2>(i) * 50));
        text.setFont(font);
        text.setCharacterSize(48);
        text.setFillColor(sf::Color::White);
		//std::get<2>(i) is the index of the value in the vector
        val = std::to_string(std::get<1>(i)[std::get<2>(i)]);
        _optionsText.push_back(std::make_tuple(name, val, new sf::Text(text)));
        //get in the vector of size_t using the last arg witch is the index of the value
    }
}

void Sfml::displayConfig(size_t _menuChoice, std::vector<std::tuple<std::string, std::vector<size_t>, size_t>> _options)
{

    _window.clear(sf::Color::Black);
    sf::Font font;
    if (!font.loadFromFile("assets/font.ttf"))
        std::cout << "error loading font" << std::endl;
    for (size_t i = 0; i < _optionsText.size(); i++) {
		std::get<1>(_optionsText[i]) = std::to_string(std::get<1>(_options[i])[std::get<2>(_options[i])]);		
		std::get<2>(_optionsText[i])->setString(std::get<0>(_optionsText[i]) + " : " + std::get<1>(_optionsText[i]));
        if (i == _menuChoice)// if the current option is the one selected set the color to the text not the value
			std::get<2>(_optionsText[i])->setFillColor(sf::Color::Red);
        else
            std::get<2>(_optionsText[i])->setFillColor(sf::Color::White);
		std::get<2>(_optionsText[i])->setPosition(sf::Vector2f(50, 50 + (i * 100)));
        //setfont and size of the text
		std::get<2>(_optionsText[i])->setFont(font);
		std::get<2>(_optionsText[i])->setCharacterSize(48);
		_window.draw(*std::get<2>(_optionsText[i]));
    }
    _window.display();
}

int Sfml::get_key()
{
    sf::Event event;

    while (_window.pollEvent(event)) {
        if (event.type == sf::Event::Closed)
            return -2;  
        else if (event.type == sf::Event::EventType::KeyPressed) {
            return event.key.code;
        }
    }
    return -1;
}


void Sfml::deleteAssets()
{
	
}