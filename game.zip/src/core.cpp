/*
** EPITECH PROJECT, 2023
** B-OOP-400-PAR-4-1-arcade-titien.carellas
** File description:
** core.cpp
*/

#include "core.hpp"
#include <dlfcn.h>
#include <thread>

core::core()
{
    _key = 0;
    _game = nullptr;
    _graphical = nullptr;
    _clock_start = std::chrono::high_resolution_clock::now();
    _clock_end = std::chrono::high_resolution_clock::now();
	_clock_start_fixed = std::chrono::high_resolution_clock::now();
	_clock_end_fixed = std::chrono::high_resolution_clock::now();
}


void core::initGame()
{
	_graphical->load_text(_game->loadTexts());
    _graphical->load_assets(_game->loadAssets());
} 

core::core(const std::string &libGraphic)
{
    _key = 0;
    _game = nullptr;
    _graphical = nullptr;
    _clock_start = std::chrono::high_resolution_clock::now();
    _clock_end = std::chrono::high_resolution_clock::now();    
	_clock_start_fixed = std::chrono::high_resolution_clock::now();
	_clock_end_fixed = std::chrono::high_resolution_clock::now();
	loadGraphical(libGraphic);
	initMenu();
	initConfig();
	_state = MENU;
	_currentGraphicLibrary = libGraphic;
	_currentGameLibraryPath = ""; // Set to an empty string initially, update it when a game library is loaded
}

core::~core()
{
    std::cout << "core closed" << std::endl;
}

void core::writeConfig()
{
    std::ofstream file("configure/graphical.conf");
    size_t second_value_res = std::get<1>(_optionsConfig[0])[std::get<2>(_optionsConfig[0])] / 1.77777777;
    if (file.is_open()) {
        file << "Resolution:" << std::get<1>(_optionsConfig[0])[std::get<2>(_optionsConfig[0])] <<" "<< second_value_res << std::endl;
        file.close();
    }
    std::ofstream file2("configure/game.conf");
    if (file2.is_open()) {
        file2 << "Skin:" << std::get<1>(_optionsConfig[1])[std::get<2>(_optionsConfig[1])];
        file2.close();
    }
}

bool core::check_time(double time, std::chrono::time_point<std::chrono::high_resolution_clock> * clock_start, std::chrono::time_point<std::chrono::high_resolution_clock> * clock_end)
{
	*clock_end = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> elapsed_seconds = (*clock_end) - (*clock_start);
	if (elapsed_seconds.count()>= time / 1000) {
        *clock_start = std::chrono::high_resolution_clock::now();
        return true;
    }
    return false;
}

void core::loadGame(const std::string &libGame)
{
    void *handle2 = dlopen(libGame.c_str(), RTLD_LAZY);
    if (!handle2) {
        std::cerr << "Cannot open library: " << dlerror() << '\n';
        exit(84);
    }
    LibGameFuncPtr createGame = (LibGameFuncPtr) dlsym(handle2, "createGameInstance");
	destroyGame = (LibGameDeletePtr) dlsym(handle2, "destroy");
    if (!createGame) {
        std::cerr << "Cannot load symbol create: " << dlerror() << '\n';
        exit(84);
    }
    _game = createGame();
	_currentGameLibraryPath = libGame; // Update the current game library path
	initGame();
	_state = GAME;
}

void core::switchGraphics(const std::string &libGraphic)
{
	destroyGraphic(_graphical);
    void *handle = dlopen(libGraphic.c_str(), RTLD_LAZY);
    if (!handle) {
        std::cerr << "Cannot open library: " << dlerror() << '\n';
        exit(84);
    }
    LibGraphicFuncPtr createGraphic = (LibGraphicFuncPtr) dlsym(handle, "createGraphicInstance");
	destroyGraphic = (LibGraphicDeletePtr) dlsym(handle, "destroy");
    if (!createGraphic) {
        std::cerr << "Cannot load symbol create: " << dlerror() << '\n';
        exit(84);
    }
    _graphical = createGraphic();
	initMenu();
	initConfig();
	_currentGraphicLibrary = libGraphic;
	if (_state == GAME) {
        initGame();
    }
}

void core::initMenu()
{
	std::vector<std::string> possibleGame {"Nibbler", "Snake"};
    _graphical->load_menu(possibleGame);
}

void core::initConfig()
{
	if (_optionsConfig.size() != 0)
		_optionsConfig.clear();
	if (_optionsMenu != 0)
		_optionsMenu = 0;
    std::vector<size_t> res;
    res.push_back(1920);
    res.push_back(1280);
    res.push_back(800);
    std::vector<size_t> skin;
    skin.push_back(0);
    skin.push_back(1);
    skin.push_back(2);
    skin.push_back(3);
    skin.push_back(4);
    skin.push_back(5);
    skin.push_back(6);
    _optionsConfig.push_back(std::make_tuple("Resolution", res, 0));
    _optionsConfig.push_back(std::make_tuple("Skin", skin, 0));
	_graphical->load_config(_optionsConfig);
}

void core::loopEnd()
{

}

void core::handleInputMenu()
{
	if (_key == KEY_ESCAPE)
        _state = END;
	if (_key == 58) {
		if (_menustate == 1)
			_menustate = 0;
        else if (_menustate == 0)
			_menustate = 1;
	}
	if (_key == 16 && _menustate == 0) {
		if (_optionsMenu >= 0)
			_optionsMenu--;
		if (_optionsMenu < 0)
			_optionsMenu = 2;
    } else if (_key == 3 && _menustate == 0) {
		if (_optionsMenu <= 2)
			_optionsMenu++;
		if (_optionsMenu > 2)
			_optionsMenu = 0;
	}
	if (_key == 74 || _key == 73 ){
		size_t currentIndex = std::distance(_graphicLibraries.begin(), std::find(_graphicLibraries.begin(), _graphicLibraries.end(), _currentGraphicLibrary));
		if (_key == 74) {
			currentIndex = (currentIndex + 1) % _graphicLibraries.size();
		} else if (_key == 73) {
			currentIndex = (currentIndex - 1 + _graphicLibraries.size()) % _graphicLibraries.size();
		}
		switchGraphics(_graphicLibraries[currentIndex]);
	}
	if (_key == 71 || _key == 72 )
	{
		size_t currentIndex = std::distance(_gameLibraries.begin(), std::find(_gameLibraries.begin(), _gameLibraries.end(), _currentGameLibraryPath));
		if (_key == 71) {
			currentIndex = (currentIndex + 1) % _gameLibraries.size();
		} else if (_key == 72) {
			currentIndex = (currentIndex - 1 + _gameLibraries.size()) % _gameLibraries.size();
		}
		loadGame(_gameLibraries[currentIndex]);
	}
}

void core::loopMenu()
{
    // Check if it's time for the next game tick
	//Start a clock to know of much time has passed since the last update
	while (_state == MENU) {
        bool should_update_text = check_time(60, &_clock_start_fixed, &_clock_end_fixed);
        int current_key = _graphical->get_key();
        if (current_key != -1) {
            _key = current_key;
		    handleInputMenu();
        }
		_menustate = _graphical->display_menu(_optionsMenu, _menustate); 
        if (should_update_text) {
	        _key = -1;
        }
		if (_menustate == 2) {
			_menustate = 0;
			_state = GAME;
			if (_optionsMenu == 0)
				loadGame("./lib/arcade_nibbler.so");
        	else if (_optionsMenu == 1)
				loadGame("./lib/arcade_snake.so");
			else if (_optionsMenu == 2){
				_state = CONFIG;
				break;
			}
		}
		std::this_thread::sleep_for(std::chrono::milliseconds(1));
        // Update the game state if it's time for the next game tick
    }
}

void core::loadGraphical(const std::string &libGraph)
{
    void *handle = dlopen(libGraph.c_str(), RTLD_LAZY);
    if (!handle) {
        std::cerr << "Cannot open library: " << dlerror() << '\n';
        exit(84);
    }
    LibGraphicFuncPtr createGraphic = (LibGraphicFuncPtr) dlsym(handle, "createGraphicInstance");
	destroyGraphic = (LibGraphicDeletePtr) dlsym(handle, "destroy");
    if (!createGraphic) {
        std::cerr << "Cannot load symbol create: " << dlerror() << '\n';
        exit(84);
    }
    _graphical = createGraphic();
}

void core::handleInputGame() 
{
	if (_key == 74 || _key == 73 ){
		size_t currentIndex = std::distance(_graphicLibraries.begin(), std::find(_graphicLibraries.begin(), _graphicLibraries.end(), _currentGraphicLibrary));
		if (_key == 74) {
			currentIndex = (currentIndex + 1) % _graphicLibraries.size();
		} else if (_key == 73) {
			currentIndex = (currentIndex - 1 + _graphicLibraries.size()) % _graphicLibraries.size();
		}
		switchGraphics(_graphicLibraries[currentIndex]);
	}
	if (_key == 71 || _key == 72 )
	{
		size_t currentIndex = std::distance(_gameLibraries.begin(), std::find(_gameLibraries.begin(), _gameLibraries.end(), _currentGameLibraryPath));
		if (_key == 71) {
            currentIndex = (currentIndex + 1) % _gameLibraries.size();
        } else if (_key == 72) {
            currentIndex = (currentIndex - 1 + _gameLibraries.size()) % _gameLibraries.size();
        }
		loadGame(_gameLibraries[currentIndex]);
	}
}

void core::loopGame() 
{
    while (_state == GAME) {
        // Check if it's time for the next game tick
        bool should_update_game = check_time(_game->getSpeed(), &_clock_start, &_clock_end);
        int current_key = _graphical->get_key();
        // Update _key only if a new key is pressed
        if (current_key != -1) {
            _key = current_key;
			handleInputGame();
        }
        if (_key == KEY_ESCAPE) {
            _state = MENU;
			if (_game != nullptr)
			    destroyGame(_game);
	        dlclose(&_game);
			break;
		}
        if (should_update_game) {
			if (_game->update(_key) == 0) {
			    _state = HIGH_SCORE;
				break;
			}
            _key = -1; // Reset the key after updating the game
        }
		_game->updateTexts();
        _graphical->display_asset(_game->getElements());
		_graphical->display_text(_game->loadTexts());
	
		std::this_thread::sleep_for(std::chrono::milliseconds(1));
    }
}

void core::loopHighScore() 
{
    while (_state == HIGH_SCORE) {
        bool should_update_text = check_time(60, &_clock_start_fixed, &_clock_end_fixed);
        int current_key = _graphical->get_key();
        if (current_key != -1) {
            _key = current_key;
        }
        if (_key == KEY_ESCAPE) {
            _state = END;
            break;
        }
        if (should_update_text) {
            _graphical->display_high_score(_game->readScore());
        }
		std::this_thread::sleep_for(std::chrono::milliseconds(1));
    }
}

void core::handleInputConfig()
{
	if (_key == KEY_ESCAPE){
		writeConfig();
        _state = MENU;
    }
    if (_key == 25 || _key == 73){
        if (_configMenuChoice > 0)
            _configMenuChoice--;
    }
    if (_key == 18 || _key == 74){
        if ((size_t)_configMenuChoice < _optionsConfig.size() - 1)
            _configMenuChoice++;
    }
    if (_key == 71 || _key == 16){
        if (std::get<2>(_optionsConfig[_configMenuChoice]) > 0)
            std::get<2>(_optionsConfig[_configMenuChoice])--;
    }
    if (_key == 72 || _key == 3){
        if (std::get<2>(_optionsConfig[_configMenuChoice]) < std::get<1>(_optionsConfig[_configMenuChoice]).size() - 1)
            std::get<2>(_optionsConfig[_configMenuChoice])++;
    }
}

void core::loopConfig()
{
    while (_state == CONFIG) {
        bool should_update_text = check_time(60, &_clock_start_fixed, &_clock_end_fixed);
        int current_key = _graphical->get_key();
        if (current_key != -1) {
            _key = current_key;
            handleInputConfig();
        }
        if (should_update_text){
            _key = -1;
        }
        _graphical->displayConfig(_configMenuChoice, _optionsConfig);
		std::this_thread::sleep_for(std::chrono::milliseconds(1));
    }
}


void core::loop()
{
	while (_state != END) {
    	if (_graphical == nullptr) {
        	std::cerr << "Error: no graphical or game library loaded" << std::endl;
       	 	break;
    	}
		if (_state == GAME && _game != nullptr) {
        	loopGame();
    	} else if (_state == MENU) {
        	loopMenu();
    	} else if (_state == HIGH_SCORE) {
        	loopHighScore();
    	} else if (_state == CONFIG) {
        	loopConfig();
    	}
	}
	if (destroyGraphic != nullptr)
        destroyGraphic(_graphical);	
	dlclose(&_graphical);
}

void core::loadLibrariesFromDirectory(const std::string &dirPath)
{
	DIR *dir;
	struct dirent *ent;
	if ((dir = opendir(dirPath.c_str())) != nullptr) {
		while ((ent = readdir(dir)) != nullptr) {
			std::string filename = ent->d_name;
			if (filename.find(".so") != std::string::npos && filename.find("arcade_") == 0) {
				std::string fullPath = dirPath + "/" + filename;
				void *libHandle = dlopen(fullPath.c_str(), RTLD_LAZY);
				if (libHandle) {
					void *gameSymbol = dlsym(libHandle, "createGameInstance");
					void *graphicSymbol = dlsym(libHandle, "createGraphicInstance");
					if (gameSymbol != nullptr) {
						_gameLibraries.push_back(fullPath);
					} else if (graphicSymbol != nullptr) {
						_graphicLibraries.push_back(fullPath);
					}
					dlclose(libHandle);
				}
			}
		}
		closedir(dir);
	} else {
		std::cerr << "Error: Could not open directory: " << dirPath << std::endl;
	}
}

int main(int argc, char *argv[]) {
	if (argc != 2) {
		std::cerr << "Usage: " << argv[0] << " <path_to_initial_graphic_lib>" << std::endl;
		return 1;
	}

	std::string initialGraphicLibPath = argv[1];
	std::filesystem::path initialLibDirectory = std::filesystem::path(initialGraphicLibPath).parent_path();
	core core(initialGraphicLibPath);
	core.loadLibrariesFromDirectory(initialLibDirectory.string());
	core.loop();
	return 0;
}