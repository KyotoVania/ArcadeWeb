/*
** EPITECH PROJECT, 2023
** B-OOP-400-PAR-4-1-arcade-titien.carellas
** File description:
** main.hpp
*/
/**
 * @file Core.hpp
 * @brief Main Core header file.
 */
#ifndef CORE_HPP_
    #define CORE_HPP_
#include <iostream>
#include <string>
#include <vector>
#include <tuple>
#include <filesystem>
#include <dirent.h>
#include <sys/types.h>
#include "../src_graphic/IGraphic.hpp"
#include "../src_game/IGames.hpp"
#include "../shared/Position.hpp"
#include <chrono>


using LibGraphicFuncPtr = IGraphic* (*)();
using LibGameFuncPtr = IGames* (*)();
using GetIdFuncPtr = std::string (*)();
using LibGraphicDeletePtr = void (*)(IGraphic*);
using LibGameDeletePtr = void (*)(IGames*);

/**
 * @brief Enum for key values.
 */
typedef enum keys_e { //sfml value for the moment
	KEY_DOWN = 258,
	KEY_UP = 259,
	KEY_LEFT = 260,
	KEY_RIGHT = 261,
	KEY_ENTER = 10,
	KEY_BACKSPACE = 8,
	KEY_ESCAPE = 36
} keys_t;

/**
 * @brief Enum for application state values.
 */
typedef enum state_e {
	UNDEFINED = 0,
	MENU = 1,
	GAME = 2,
	HIGH_SCORE = 3,
	CONFIG = 4,
	END = 5
} state_t;

/**
 * @class core
 * @brief Main Core class for the application.
 */
class core {
public:
	/**
	 * @brief Initial
	 * \fn core()
	 * \brief Default constructor.
	 */
    core();
	/**
	 * \fn core(const std::string &libGraphical)
	 * \brief Constructor with graphical library.
	 * \param libGraphical Graphical library to load.
	 * \return core
	 */
    core(const std::string &libGraphical);
	/**
	 * \fn ~core()
	 * \brief Default destructor.
	 */
    ~core();
	/**
	 *\fn void loop()
	 *\brief Main loop of the application.
	 */
    void loop();
	/**
	 *\fn void loopGame()
	 *\brief Loop for the game state.
	 */
	void loopGame();
	/**
	 *\fn void loopMenu()
	 *\brief Loop for the menu state.
	 */
	void loopMenu();
	/**
	 *\fn void loadGame(const std::string &libGame)
	 *\brief Load a game library.
	 *\param libGame Game library to load.
	 */
    void loadGame(const std::string &libGame);
	/**
	 * \fn void loopEnd()
	 * \brief Loop for the end state.
	 */
	void loopEnd();
	/**
	 * \fn void loadGraphical(const std::string &libGraphical)
	 * \brief Load a graphical library.
	 * \param libGraphical Graphical library to load.
	 */
	void loadGraphical(const std::string &libGraphical);
	/**
	 * \fn void handleInputConfig()
	 * \brief Handle input for the config state.
	 */
	void handleInputConfig();
	/**
	 * \fn void loopHighScore()
	 * \brief Loop for the high score state.
	 */
	void loopHighScore();
	/**
	 * \fn void initGame()
	 * \brief Init the game state.
	 */
	void initGame();
	/**
	 * \fn void initMenu()
	 * \brief Init the menu state.
	 */
	void initMenu();
	/**
	 * \fn void handleInputMenu()
	 * \brief Handle input for the menu state.
	 */
	void handleInputMenu();
	/**
	 *\fn bool check_time(double time, std::chrono::time_point<std::chrono::high_resolution_clock> * clock_start, std::chrono::time_point<std::chrono::high_resolution_clock> * clock_end)
	 *\brief Check if the time is elapsed.
	 *\param time Time to check.
	 *\param clock_start Start time.
	 *\param clock_end End time.
	 *\return bool True if the time is elapsed, false otherwise.
	 */
    bool check_time(double time, std::chrono::time_point<std::chrono::high_resolution_clock> * clock_start, std::chrono::time_point<std::chrono::high_resolution_clock> * clock_end);
	/**
	 *\fn void writeConfig()
	 *\brief Write the config file.
	 */
	void writeConfig();
	/**
	 *\fn void initConfig()
	 *\brief Init the config state.
	 */
	void initConfig();
	/**
	 *\fn void loopConfig()
	 *\brief Loop for the config state.
	 */
	void loopConfig();
	/**
    *\fn void switchGraphics(const std::string &libGraphic)
	*\brief Switch the graphical library.
	*\param libGraphic Graphical library to load.
    */
	void switchGraphics(const std::string &libGraphic);
	/**
	*\fn loadLibrariesFromDirectory(const std::string &dirPath)
	*\brief Load all the libraries from a directory. 
	*\param dirPath Directory to load the libraries from.
    *\return \ref _gameLibraries and \ref _graphicLibraries are filled.
	*/
	void loadLibrariesFromDirectory(const std::string &dirPath);
	/**
	*\fn void handleInputGame()
	*\brief Handle input for the game state.
    */
	void handleInputGame();
	protected:
	/**
	*\brief Game library pointer.
	*/
    IGames* _game;
	/**
	*\brief Graphical library pointer.
	*/
    IGraphic* _graphical;
	/**
	*\brief int for the key pressed to be handled. we use sfml values so all the libraries graphical need to be compatible with sfml by being converted.
	*/
    int _key = 0;
	/**
	*\brief _optionsMenu is used to know which menu option is selected. 0 will launch nibbler, 1 will launch snake, 2 will launch the config menu.
    */
	int _optionsMenu = 0;
	/**
	*\brief _menustate is used to know in which state of the confirmation menu we are. 
	* 0 = wait for input
	* 1 = is loading, the lauch can still be stoped
	* 2 = is loaded so it launches the game.
    */
	int _menustate = 0;
	/**
	*\brief _state is used to know in which state of the application we are.
	* 0 = undefined
	* 1 = menu
	* 2 = game
	* 3 = high score
	* 4 = config
	* 5 = end
    */
	int _state = UNDEFINED;
	/**
	*\brief _optionsConfig is used to know the possible values for the config menu.
	* 0 = res 
	* \t 0 = 800x600
	* \t 1 = 1280x1024
	* \t 2 = 1920x1080
	* 1 = skin
	* \t 0 = default
	* \t 1 = classic
	* \t 2 = retro
	* \t 3 = rainbow
	* \t 4 = classic variant
	* \t 5 = retro variant
	* \t 6 = cave variant
    */
	std::vector<std::tuple<std::string, std::vector<size_t>, size_t>> _optionsConfig;
	/**
	*\brief _configMenuChoice is used to know which option is selected in the config menu.
	* 0 = res
	* 1 = skin
	* 2 = quit
    */
	size_t _configMenuChoice = 0; //0 = res 1 = skin 3 = quit
	/**
	* \brief destroyGraphic is used to destroy the graphical library.
    */
	LibGraphicDeletePtr destroyGraphic;
	/**
	* \brief destroyGame is used to destroy the game library.
    */
	LibGameDeletePtr destroyGame;
	/**
	* \brief _gameLibraries is used to store the game libraries in a vector.
    */
 	std::vector<std::string> _gameLibraries;
	/**
	* \brief _graphicLibraries is used to store the graphical libraries in a vector.
    */ 
	std::vector<std::string> _graphicLibraries;
	/**
	* \brief _currentGraphicLibrary is used to store the current graphical library.
    */
	std::string _currentGraphicLibrary;
	/**
	* \brief _currentGameLibrary is used to store the current game library.
    */
	std::string _currentGameLibraryPath;
	/**
	* \brief _clock_start is used to store the start time with \ref _clock_end to calculate the time elapsed. with the _game->speed it will be used to know if the game needs to be updated.
    */
    std::chrono::time_point<std::chrono::high_resolution_clock> _clock_start;
	/**
	* \brief _clock_end is used to store the end time with \ref _clock_start to calculate the time elapsed. with the _game->speed it will be used to know if the game needs to be updated.
    */
    std::chrono::time_point<std::chrono::high_resolution_clock> _clock_end;
	/**
	* \brief _clock_start_fixed is used to store the start time with \ref _clock_end_fixed to calculate the time elapsed. its based with a 60fps so it will be used to know when some dynamic ressource such as the text, timer etc... need to be updated.
    */
    std::chrono::time_point<std::chrono::high_resolution_clock> _clock_start_fixed;
	/**
	* \brief _clock_end_fixed is used to store the end time with \ref _clock_start_fixed to calculate the time elapsed. its based with a 60fps so it will be used to know when some dynamic ressource such as the text, timer etc... need to be updated.
    */
    std::chrono::time_point<std::chrono::high_resolution_clock> _clock_end_fixed;
private:
};

#endif /*MAIN_HPP_*/