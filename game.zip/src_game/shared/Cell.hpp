/*
** EPITECH PROJECT, 2023
** B-OOP-400-PAR-4-1-arcade-titien.carellas
** File description:
** Cell.hpp
*/
#ifndef CELL_HPP_
	#define CELL_HPP_
#include "../../shared/Position.hpp"
#include <cstddef>
#include <iostream>
#include <vector>


class Cell
{
	public:
	Cell();
	Cell(int x, int y);
	~Cell();
	void setPos(int x, int y);
	void setPos(Position pos);
	Position getPos();
	int getX();
	int getY();
	direction_t getRotation();
	bool checkCollision(Position pos);
	void setRotation(direction_t dir);
	protected:
	Position _pos;
};
#endif /*CELL_HPP_*/