/*
** EPITECH PROJECT, 2023
** B-OOP-400-PAR-4-1-arcade-titien.carellas
** File description:
** PlayerS.hpp
*/
#ifndef PLAYER_SNAKE_HPP_
	#define PLAYER_SNAKE_HPP_
#include <vector>
#include "Cell.hpp"


class PlayerS
{
	public:
		PlayerS();
		PlayerS(int x, int y);
		~PlayerS();
		void move(Position pos);
		Position getHeadPos();
		Position getBodyPos(int i);
		Position getTailPos();
		size_t getSize();
		void grow();
		void setRotation(direction_t dir);
		direction_t getRotation();
		bool checkCollision(Position pos);
		bool checkEatHimself();
		std::vector<Position> getSnakePosVector();
		std::vector<Position> getSnakeTailPosVector();
		void RespawnAt(Position pos);
	private:
	size_t _size = 0;
	std::vector<Cell> _body;
};

#endif /*PLAYER_SNAKE_HPP_*/