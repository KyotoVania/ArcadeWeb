/*
** EPITECH PROJECT, 2023
** B-OOP-400-PAR-4-1-arcade-titien.carellas
** File description:
** PlayerS.cpp
*/
//PlayerS stand for the snake but to avoid confusion with the snake class (wich is the game) i called it PlayerS

#include "PlayerS.hpp"
#include <iostream>

PlayerS::PlayerS()
{
    _size = 3;
    //create 3 cells
    std::vector<Cell>cells {
    Cell(),
    Cell(),
        Cell()
    };
    _body = cells;
	for (size_t i = 0; i < _size; i--) {
        _body[i].setPos(i, 0);
    }
    _body[0].setRotation(RIGHT);
	//set orientation of the snake to the right

}

PlayerS::PlayerS(int x, int y)
{
    _size = 3;
    //create 3 cells
    std::vector<Cell>cells {
    Cell(),
    Cell(),
        Cell()
    };
    _body =  cells;
    for (size_t i = 0; i < _size; i++) {
        _body[i].setPos(x - i, y);
    }   
}

PlayerS::~PlayerS()
{
    for (std::size_t i = 0; i < _size; i++)
    {
        //delete _body[i];
    }
}

Position PlayerS::getHeadPos()
{
    return _body[0].getPos();
}

void PlayerS::move(Position pos)
{
    for (size_t i = _size - 1; i > 0; i--) {
        _body[i].setPos(_body[i - 1].getPos());
    }
    _body[0].setPos(pos);

}

Position PlayerS::getBodyPos(int i)
{
    return _body[i].getPos();
}

size_t PlayerS::getSize()
{
    return _size;
}

void PlayerS::setRotation(direction_t dir)
{
    _body[0].setRotation(dir);
}

direction_t PlayerS::getRotation()
{
    return _body[0].getRotation();
}

void PlayerS::grow()
{
    _size++;
    _body.push_back(Cell());
    _body[_size - 1].setPos(_body[_size - 2].getX(), _body[_size - 2].getY());
}

Position PlayerS::getTailPos()
{
    return _body[_size - 1].getPos();
}

bool PlayerS::checkCollision(Position pos)
{
    for (size_t i = 0; i < _size; i++) {
        if (_body[i].checkCollision(pos))
            return true;
    }
    return false;
}

bool PlayerS::checkEatHimself()
{
    //check if head is on the same position as a body part
	 for (size_t i = 1; i < _size; i++) {
        if (_body[0].checkCollision(_body[i].getPos())){
            return true;
		}
    }
	return false;
}

std::vector<Position> PlayerS::getSnakePosVector()
{
    std::vector<Position> pos;
    for (size_t i = 0; i < _size; i++) {
        pos.push_back(_body[i].getPos());
    }
	//print all the cells pos x and y


    return pos;
}

std::vector<Position>PlayerS::getSnakeTailPosVector()
{
    std::vector<Position> pos;
   	// we want to get the tail position of the snake and create a vector with the 3 posible positions x-1, x+1, y+1 
	Position tail = getTailPos();
	Position pos1 = Position(tail.getX() - 1, tail.getY());
	Position pos2 = Position(tail.getX() + 1, tail.getY());
	Position pos3 = Position(tail.getX(), tail.getY() + 1);
	Position pos4 = Position(tail.getX(), tail.getY() - 1);
	pos.push_back(pos1);
	pos.push_back(pos2);
	pos.push_back(pos3);
	pos.push_back(pos4);
    return pos;
}


void PlayerS::RespawnAt(Position pos)
{
    for (size_t i = 1; i < _size; i++) {
        _body[i].setPos(pos.getX() - 1, pos.getY());
    }
    _body[0].setPos(pos.getX(), pos.getY());
    //maybe the head will be changed to a different position
}