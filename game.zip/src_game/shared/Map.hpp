/*
** EPITECH PROJECT, 2023
** B-OOP-400-PAR-4-1-arcade-titien.carellas
** File description:
** Map.hpp
*/
#ifndef MAP_HPP_
	#define MAP_HPP_

#include <vector>
#include "Cell.hpp"

class Map
{
	public:
		Map();
		Map(std::vector<Position>& positions);
		~Map();
		std::vector<Cell> getMap();
		Position getPosition(int index);
		std::vector<Position> getPositionsVector();
		protected:
		std::vector<Cell> _map;
};

#endif /*MAP_HPP_*/