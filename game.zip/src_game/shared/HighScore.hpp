/*
** EPITECH PROJECT, 2023
** B-OOP-400-PAR-4-1-arcade-titien.carellas
** File description:
** HighScore.hpp
*/
#ifndef HIGHSCORE_HPP_
	#define HIGHSCORE_HPP_

#include <vector>
#include <string>
#include <fstream>
#include <iostream>
#include <algorithm>
#include <pwd.h>
#include <unistd.h>


class HighScore
{
	public:
	std::vector<std::string> writeScore(std::string gameName, size_t _score);
	std::vector<std::string> getTop10Reverse(const std::vector<std::string>& lines, std::string gameName);
	std::string getLogin();
	std::vector<std::string> readScore(std::string gameName);
};

#endif /*HIGHSCORE_HPP_*/