/*
** EPITECH PROJECT, 2023
** B-OOP-400-PAR-4-1-arcade-titien.carellas
** File description:a
** HighScore.cpp
*/

#include "HighScore.hpp"
int extractScore(const std::string& line) {
    if (line.empty()) {
        return -1;
    }
    try {
        return std::stoi(line.substr(line.find_last_of(" ") + 1));
    } catch (const std::invalid_argument&) {
        std::cout << "Error converting score in line: " << line << std::endl;
        return -1;
    }
}


std::string HighScore::getLogin(){
    char* login = getlogin();
    if (login != nullptr) {
        return std::string(login);
    }
    return "";
}

std::vector<std::string> HighScore::getTop10Reverse(const std::vector<std::string>& lines, std::string gameName) {
    std::vector<std::string> gamenamelist;
    std::vector<std::string> top10;
    int count = 0;
    for (auto &i : lines) {
        if (i.find(gameName) != std::string::npos) {
            gamenamelist.push_back(i);
        }
    }

    //now check to get the top 10
    for (auto &i : gamenamelist) {
        if (count < 10) {
            top10.push_back(i);
            count++;
        }
    }
    std::sort(top10.begin(), top10.end(), [](const std::string& a, const std::string& b) {
        return extractScore(a) > extractScore(b);
    });

    //now reverse the vector
    return top10;
}


std::vector<std::string> HighScore::writeScore(std::string gameName, size_t _score)
{
    std::vector<std::string> highScore;
    std::fstream file;
    std::string line;
    std::string name = getLogin();
    std::string score_tocheck;

    file.open("HighScore.txt", std::ios::in | std::ios::out);
    if (!file.is_open()) {
        std::cout << "file not opened" << std::endl;
        throw std::exception();
    }

    // Read the contents of the file into memory
    std::vector<std::string> lines;
    while (std::getline(file, line)) {
        lines.push_back(line);
    }
    //print the vector
    // Sort the lines vector by score //LAMBDA EXPRESSION go to wikipedia if you don't know what it is

    // Check if the new score is in the top 10
    // Check if the new score is in the top 10
    bool is_top_10 = false;
    std::vector<std::string> top10_reverse = getTop10Reverse(lines, gameName);
    int replace_index = -1;
    for (int i = 0; i < static_cast<int>(top10_reverse.size()); ++i) {
        const auto& line = top10_reverse[i];
        size_t score = std::stoi(line.substr(line.find_last_of(" ") + 1));
        if (_score > score && is_top_10 == false) {
            is_top_10 = true;
            replace_index = i;
        }
    }

    if (is_top_10 && replace_index != -1) {
        top10_reverse[replace_index] = name + " " + gameName + " " + std::to_string(_score);
    }
    
    if (is_top_10) {
        //re reverse the vector
        // We want to get all the other lines in the file to not lose the high scores of other games
        std::vector<std::string> updated_lines;
        for (const auto& l : lines) {
            if (l.find(gameName) == std::string::npos) {
                updated_lines.push_back(l);
            }
        }
        // Add the top 10 scores of the current game to the updated_lines vector
        for (const auto& l : top10_reverse) {
            updated_lines.push_back(l);
        }
        // Clear the file and rewrite the updated_lines to the file
        file.clear();
        file.seekp(0);
        for (const auto& l : updated_lines) {
            file << l << std::endl;
        }
    }
    // Append the updated contents of the file to the highScore vector
    for (const auto& l : top10_reverse) {
		if (l.find(gameName) != std::string::npos)
	        highScore.push_back(l);
    }
    // Close the file
    file.close();
    return highScore;
}

std::vector<std::string> HighScore::readScore(std::string gameName)
{
//we just want to return the 10line corresponding to the game name given

    std::vector<std::string> highScore;
    std::fstream file;
    std::string line;

    file.open("HighScore.txt", std::ios::in | std::ios::out);
    if (!file.is_open()) {
        std::cout << "file not opened" << std::endl;
        throw std::exception();
    }
    for (int i = 0; highScore.size() < 10; i++) {
        std::getline(file, line);
        if (line.find(gameName) != std::string::npos) {
            highScore.push_back(line);
        }
    }
    file.close();
    return highScore;
}