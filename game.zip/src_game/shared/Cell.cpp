/*
** EPITECH PROJECT, 2023
** B-OOP-400-PAR-4-1-arcade-titien.carellas
** File description:
** Cell.cpp
*/

#include "Cell.hpp"

Cell::Cell()
{
    _pos = Position(0, 0);
}

Cell::Cell(int x, int y)
{
    _pos = Position(x, y);
}

Cell::~Cell()
{
}

void Cell::setPos(int x, int y)
{
    _pos.setX(x);
    _pos.setY(y);
}

void Cell::setPos(Position pos)
{
    _pos.setX(pos.getX());
    _pos.setY(pos.getY());
}

Position Cell::getPos()
{
    return _pos;
}

int Cell::getX()
{
    return _pos.getX();
}

int Cell::getY()
{
    return _pos.getY();
}

direction_t Cell::getRotation()
{
    return _pos.getRotation();
}

void Cell::setRotation(direction_t dir)
{
    _pos.setRotation(dir);
}

bool Cell::checkCollision(Position pos)
{
    if (_pos.getX() == pos.getX() && _pos.getY() == pos.getY())
        return true;
    return false;
}