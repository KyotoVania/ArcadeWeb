/*
** EPITECH PROJECT, 2023
** B-OOP-400-PAR-4-1-arcade-titien.carellas
** File description:
** Food.cpp
*/
#include "Food.hpp"
#include <iostream>

Food::Food()
{
	//use cell constructor
	_pos = Position(0, 0);
}

Food::Food(int x, int y)
{
	_pos = Position(x, y);
}

std::pair<int, int> Food::respawn(std::vector<Position> mapPos, std::vector<Position> pos_snake, std::vector<Position> possible_pos)
{
	
	for (auto pos : possible_pos){
		bool valid_position = true;

		for (auto map : mapPos){
			if (pos.getPosPair() == map.getPosPair()) {
				valid_position = false;
				break;
			}
		}

		if (valid_position) {
			for (auto snake : pos_snake){
				if (pos.getPosPair() == snake.getPosPair()) {
					valid_position = false;
					break;
				}
			}
		}
		if (valid_position) {
			return pos.getPosPair();
		}
	}

	Position pos_rand((rand() % 5) + 1, (rand() % 5) + 1);
	return pos_rand.getPosPair();
}

// Path: test_env/Map.cpp
