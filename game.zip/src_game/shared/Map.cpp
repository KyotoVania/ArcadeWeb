/*
** EPITECH PROJECT, 2023
** B-OOP-400-PAR-4-1-arcade-titien.carellas
** File description:
** Map.cpp
*/

#include "Map.hpp"

Map::Map()
{
    //init map
    for (int i = 0; i < 12; i++) {
        for (int j = 0; j < 8; j++) {
            //only create cells on the border we will use for the first time the constructor of the cell class with the x , y and orientation.
            //if its at the left border we send the orientation to the left and so on
            if (i == 0 || i == 11 || j == 0 || j == 7) {
                Cell cell;
                cell.setPos(i, j);
                if (j == 0)
                {
                    cell.setRotation(RIGHT);
                }
                else if (i == 0 )
                {
                    cell.setRotation(UP);
                }
                else if (i == 11)
                {
                    cell.setRotation(DOWN);
                }
                else
                    cell.setRotation(LEFT);
                _map.push_back(cell);
            }
        }
    }
}

Map::Map(std::vector<Position>& positions)
{
    //need to set the rotation of the cells we know all the map are 20 x 17 so we will set the rotation only for the cells at the border
    //we will create 4 variables for the border based on the map size
    int leftBorder = 0;
    int rightBorder = 18;
    int topBorder = 0;
    int bottomBorder = 16;
    for (std::size_t i = 0; i < positions.size(); i++)
    {
        Cell cell;
        cell.setPos(positions[i].getX(), positions[i].getY());
        if (positions[i].getY() == bottomBorder)
        {
            cell.setRotation(DOWN);
        }
        else if (positions[i].getY() == topBorder)
        {
            cell.setRotation(UP);
        }
        else if (positions[i].getX() == leftBorder)
        {
            cell.setRotation(LEFT);
        }
        else if (positions[i].getX() == rightBorder)
        {
            cell.setRotation(RIGHT);
        } else
            cell.setRotation(UP);
        _map.push_back(cell);
    }
}

Map::~Map()
{
    for (std::size_t i = 0; i < _map.size(); i++)
    {
        delete &_map[i];
    }
}

std::vector<Cell> Map::getMap()
{
    return _map;
}

Position Map::getPosition(int index)
{
    return _map[index].getPos();
}

std::vector<Position> Map::getPositionsVector()
{
    std::vector<Position> pos;
    for (std::size_t i = 0; i < _map.size(); i++)
    {
        pos.push_back(_map[i].getPos());
    }
    return pos;
}