/*
** EPITECH PROJECT, 2023
** B-OOP-400-PAR-4-1-arcade-titien.carellas
** File description:
** Food.hpp
*/
#ifndef FOOD_HPP_
	#define FOOD_HPP_

#include "Cell.hpp"


class Food : public Cell
{
	//erit of all the functions from cell class
	public:
	Food();
	Food(int x, int y);
	std::pair<int, int> respawn(std::vector<Position> mapPos, std::vector<Position> pos_snake, std::vector<Position> possible_pos);
};
#endif /*FOOD_HPP_*/