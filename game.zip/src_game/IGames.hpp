/*
** EPITECH PROJECT, 2023
** B-OOP-400-PAR-4-1-arcade-titien.carellas
** File description:
** IGames.hpp
*/
#ifndef IGAMES_HPP_
	#define IGAMES_HPP_
#include <iostream>
#include <string>
#include <vector>
#include <tuple>
#include <map>
#include <fstream>
#include <chrono> 
#include <unistd.h>
//include sort and getlogin
#include <algorithm>
#include <pwd.h>
#include "../shared/Position.hpp"
#include "shared/Cell.hpp"
#include "shared/Map.hpp"
#include "shared/Food.hpp"
#include "shared/PlayerS.hpp"
#include "shared/HighScore.hpp"

/**
 * \class IGames
 * \brief Interface for handling games
 *
 * This class is an interface for handling games in the arcade program. 
 * such as the snake, the food, the map, the score, the speed, the collision, the input, the texts, the score,
 * the highscore, the time
 */


class IGames {
	public:
		virtual ~IGames() = default;
		/**
		 * \fn virtual void init() = 0;
		 * \brief Initialize the game
		 *
		 * This function is used to initialize the game
		 */
		virtual void init() = 0;
		/**
		 * \fn virtual bool update(int key) = 0;
		 * \brief Update the game based on the key pressed
		 * \param key The key pressed for handling the input later
		 * \return true if the game is still running, false if the game is over
		 */
		virtual bool update(int key) = 0;
		/**
		 * \fn virtual std::vector<std::tuple<char, std::string, int>> loadAssets() = 0;
		 * \brief Load the assets of the game
		 * \return A vector of tuple containing the character, the path to the asset and the index for the spritesheet
		 */
		virtual std::vector<std::tuple<char, std::string, int>> loadAssets() = 0;
		/**
		 * \fn virtual std::vector<std::tuple<char, Position>> getElements() = 0;
		 * \brief Get the elements of the game
		 * \return A vector of tuple containing the character and the position of the element
		 */
		virtual std::vector<std::tuple<char, Position>> getElements() = 0;
		/**
		 * \fn virtual std::tuple<std::vector<Position>, std::vector<Position>> parse_map(std::string map_name) = 0;
		 * \brief Parse the map
		 * \param map_name The name of the map
		 * \return A tuple containing a vector of position for the walls and a vector of position for the food
		 */
		virtual std::tuple<std::vector<Position>, std::vector<Position>> parse_map(std::string map_name) = 0;
		/**
		 * \fn virtual double getScore() = 0;
		 * \brief Get the score of the game
		 * \return A double containing the score
		 */
		virtual double getScore() = 0;
		/**
		 * \fn virtual size_t getSpeed() = 0;
		 * \brief Get the speed of the game
		 * \return A size_t containing the speed
		 */
	    virtual size_t getSpeed() = 0;
		/**
		 *\fn virtual void handleCollision() = 0;
		 *\brief Handle the collision of the game
		 */
		virtual void handleCollision() = 0;
		/**
		 *\fn virtual void handleInput(int key) = 0;
		 *\brief Handle the input of the game
		 *\param key The key pressed
		 */
		virtual void handleInput(int key) = 0;
		/**
		 * \fn virtual bool collisionMap(Position pos) = 0;
		 * \brief Check if the position is a wall
		 * \param pos The position to check
		 * \return true if the position is a wall, false if not
		 */
		virtual bool collisionMap(Position pos) = 0;
		/**
		 * \fn virtual bool collisionFood(Position pos) = 0;
		 * \brief Check if the position is a food
		 * \param pos The position to check
		 * \return true if the position is a food, false if not
		 */
		virtual void collisionFood() = 0;
		/**
		 * \fn virtual std::vector<std::tuple<std::string, Position>> loadTexts() = 0;
		 * \brief Load the texts of the game
		 * \return A vector of tuple containing the string and the position of the text
		 */
		virtual std::vector<std::tuple<std::string, Position>> loadTexts() = 0;
		/**
		 * \fn virtual void updateTexts() = 0;
		 * \brief Update the texts of the game
		 */
		virtual void updateTexts() = 0;
		/**
		 * \fn virtual std::vector<std::string> writeScore() = 0;
		 * \brief Write the score of the game
		 * \return A vector of string containing the score
		 */
		virtual std::vector<std::string> writeScore() = 0;
		/**
		 * \fn virtual std::vector<std::string> readScore() = 0;
		 * \brief Read the score of the game
		 * \return A vector of string containing the score
		 */
		virtual std::vector<std::string> readScore() = 0;
		/**
		 * \fn virtual void writeConfig() = 0;
		 * \brief Write the config of the game
		 * \return A vector of string containing the config
		 */
	    virtual void readConfig() = 0;
	protected:
	
	private:
};

#endif /*IGAMES_HPP_*/