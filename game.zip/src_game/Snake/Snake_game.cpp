/*
** EPITECH PROJECT, 2023
** B-OOP-400-PAR-4-1-arcade-titien.carellas
** File description:
** Snake.cpp
*/


#include "Snake_game.hpp"


extern "C" IGames *create()
{
	return new Snake();
}

extern "C" IGames *createGameInstance()
{
	return new Snake();
}

extern "C" std::string getName()
{
	return "Snake";
}

extern "C" void destroy(IGames *game)
{
	delete game;
}


Snake::Snake()
{
	init();
}

Snake::~Snake()
{
}

void Snake::readConfig()
{
    std::ifstream file("configure/game.conf");
    std::string line;
    std::string name;
    std::string value;
    int i = 0;

    if (file.is_open()) {
        while (getline(file, line)) {
            name = line.substr(0, line.find(":"));
            value = line.substr(line.find(":") + 1, line.size());
            _configData.push_back(std::pair(name, value));
            i++;
        }
    }
    file.close();

    for (auto& asset : _configData) {
        if (std::get<0>(asset) == "Skin")
			_skinMultiplier = std::stoi(std::get<1>(asset));
    }
}

void Snake::init()
{
	readConfig();
	std::tuple<std::vector<Position>, std::vector<Position>> pos_map_foods = parse_map("1.levels");
	//init snake
	_snake = new PlayerS(9,9); // TODO: snake is supposed to be at the center of the map (nibbler will be at the bottom).
	_snake->setRotation(RIGHT);
	//init food
	_food = new Food();
	//print the location in the tuple its vector so there is multiple position
	//init map with the second position in the tuple
	_map = new Map(std::get<0>(pos_map_foods));
	_food->setPos(5,4);
	_score = 0;
	initTexts();
}

void Snake::initTexts()
{
    _string.push_back(std::make_tuple("Score: " + std::to_string(_score), Position(300, 0)));
    _string.push_back(std::make_tuple("Highscore: " + std::to_string(_highScore), Position(650, 0)));
    _string.push_back(std::make_tuple("Level: " + std::to_string(_level), Position(300, 100)));
}

std::vector<std::tuple<char, std::string, int>> Snake::loadAssets()
{
    std::vector<std::tuple<char, std::string, int>> assetsToSend;
    assetsToSend.push_back(std::make_tuple('H', "fullRessource.png", 0 + (8 * _skinMultiplier)));//head
    assetsToSend.push_back(std::make_tuple('I', "fullRessource.png", 4 + (8 * _skinMultiplier)));//body
    assetsToSend.push_back(std::make_tuple('*', "fullRessource.png", 5 + (8 * _skinMultiplier)));//food
    assetsToSend.push_back(std::make_tuple(' ', "fullRessource.png", 50));//empty
    assetsToSend.push_back(std::make_tuple('M', "fullRessource.png", 7 + (8 * _skinMultiplier)));//map
	
    return assetsToSend;
}

std::vector<std::tuple<std::string, Position>> Snake::loadTexts()
{
    return _string;
}

void Snake::updateTexts()
{
    _string[0] = std::make_tuple("Score: " + std::to_string(_score), Position(300, 0));
    _string[1] = std::make_tuple("Highscore: " + std::to_string(_highScore), Position(650, 0));
    _string[2] = std::make_tuple("Level: " + std::to_string(_level), Position(300, 100));
}

std::vector<std::tuple<char, Position>> Snake::getElements()
{
    std::vector<std::tuple<char, Position>> elements;
    elements.push_back(std::make_tuple('H', _snake->getHeadPos()));
	for (size_t i = 1; i < _snake->getSize(); i++) {
	    elements.push_back(std::make_tuple('I', _snake->getBodyPos(i)));
	}
	for (size_t i = 0; i < _map->getMap().size(); i++) {
		elements.push_back(std::make_tuple('M', _map->getPosition(i)));
	}

    elements.push_back(std::make_tuple('*', _food->getPos()));
	return elements;
}


bool Snake::collisionMap(Position pos)
{

	for (size_t i = 0; i < _map->getMap().size(); i++) {
		if (pos.getX() == _map->getPosition(i).getX() && pos.getY() == _map->getPosition(i).getY())
			return true;
	}
	return false;
}

void Snake::collisionFood()
{
	if (_food->checkCollision(_snake->getHeadPos())) {
		//add cell to snake
		std::pair<int, int> pos = _food->respawn(_map->getPositionsVector(), _snake->getSnakePosVector(), _snake->getSnakeTailPosVector());
		//check if the new pair is not in the snake body if it is respawn again
		_food->setPos(pos.first, pos.second);
		_snake->grow();
		_score += 5;
		if (_score % 25 == 0)
            _level += 1;
		_speed -= 1;
	}
}

void Snake::handleCollision()
{
	collisionFood();
}

bool Snake::update(int key)
{
	handleInput(key);
	if (_score > _highScore)
        _highScore = _score;
	handleCollision();
	if (collisionMap(_snake->getHeadPos()) || _snake->checkEatHimself()) {
		return false;
	}
	return true;
}

double Snake::getScore()
{
	return _score;
}

size_t Snake::getSpeed()
{
	return _speed;
}

void Snake::handleInput(int key)
{
    Position position_tmp(_snake->getHeadPos().getX(), _snake->getHeadPos().getY());
    if (key == 25){
        //move up
        if (_snake->getRotation() == direction_t::DOWN)
            goto autoMoveS;
        position_tmp.setY(position_tmp.getY() - 1);
        _snake->move(position_tmp);
        _snake->setRotation(direction_t::UP);
    } else if (key == 18){
        //move down
        if (_snake->getRotation() == direction_t::UP)
            goto autoMoveS;
        position_tmp.setY(position_tmp.getY() + 1);
        _snake->move(position_tmp);
        _snake->setRotation(direction_t::DOWN);
    } else if (key == 3 ){
        //move right check the direction before it need to not be the opposite
        if (_snake->getRotation() == direction_t::LEFT)
            goto autoMoveS;
        position_tmp.setX(position_tmp.getX() + 1);
        _snake->move(position_tmp);
        _snake->setRotation(direction_t::RIGHT);
    } else if (key == 16){
        //move left
        if (_snake->getRotation() == direction_t::RIGHT)
            goto autoMoveS;
        position_tmp.setX(position_tmp.getX() - 1);
        _snake->move(position_tmp);
        _snake->setRotation(direction_t::LEFT);
    } else {
autoMoveS:
        if (_snake->getRotation() == direction_t::UP) {
            position_tmp.setY(position_tmp.getY() - 1);
        } else if (_snake->getRotation() == direction_t::RIGHT) {
            position_tmp.setX(position_tmp.getX() + 1);
        } else if (_snake->getRotation() == direction_t::DOWN) {
            position_tmp.setY(position_tmp.getY() + 1);
        } else if (_snake->getRotation() == direction_t::LEFT) {
            position_tmp.setX(position_tmp.getX() - 1);
        }
        _snake->move(position_tmp);
    }
}


std::tuple<std::vector <Position>, std::vector < Position > > Snake::parse_map(std::string map_name)
{
    std::vector <Position> walls;
    std::vector <Position> food;
    std::ifstream file;
    std::string line;
    int x = 0;
    int y = 0;

    file.open("Levels/" + map_name);
    if (!file.is_open()) {
        std::cout << "file not opened" << std::endl;
        throw std::exception();
    }
    while (std::getline(file, line)) {
        for (auto &i : line) {
            if (i == 'W') {
                walls.push_back(Position(x, y));
            }
            else if (i == 'F') {
                food.push_back(Position(x, y));
            }
            x++;
        }
        x = 0;
        y++;
    }
    file.close();
	//print the map for debugging
    return std::make_tuple(walls, food);
}

std::vector<std::string> Snake::writeScore()
{
	HighScoreIsSet = true;
	return _highscore->writeScore("Snake", _score);
}

std::vector<std::string>  Snake::readScore()
{
	if (HighScoreIsSet == false)
		return writeScore();
	
    return _highscore->readScore("Snake");
}
