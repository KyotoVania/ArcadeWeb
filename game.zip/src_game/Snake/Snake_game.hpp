/*
** EPITECH PROJECT, 2023
** B-OOP-400-PAR-4-1-arcade-titien.carellas
** File description:
** Snake.hpp
*/
#ifndef SNAKE_HPP_
	#define SNAKE_HPP_

#include "../IGames.hpp"
#include <iostream>

class Snake : public IGames{
	public:
		Snake();
		Snake(int x, int y);
		~Snake();
		virtual void init();
		virtual void initTexts();
		virtual bool update(int key);
		virtual std::vector<std::tuple<char, std::string, int>> loadAssets();
		virtual std::vector<std::tuple<char, Position>> getElements();
		virtual std::tuple<std::vector<Position>, std::vector<Position>> parse_map(std::string map_name);
		virtual double getScore();
	    virtual size_t getSpeed();
		virtual void handleCollision();
		virtual void handleInput(int key);
		virtual bool collisionMap(Position pos);
		virtual void collisionFood();
		virtual std::vector<std::tuple<std::string, Position>> loadTexts();
		virtual void updateTexts();
		virtual std::vector<std::string> writeScore();
		virtual std::vector<std::string> readScore();
		virtual void readConfig();
		std::string getLogin();
	protected:
		bool HighScoreIsSet = false;
		size_t _skinMultiplier = 0;
		size_t _speed = 150;
		size_t _score = 0;
		size_t _highScore = 0;
		size_t _level = 1;
		Food* _food;
		Map* _map;
		PlayerS* _snake;
		HighScore* _highscore;
		std::vector<std::tuple<std::string, Position>> _string;
		std::vector<std::pair<std::string, std::string>> _configData;
	private:	
};

#endif /*SNAKE_HPP_*/