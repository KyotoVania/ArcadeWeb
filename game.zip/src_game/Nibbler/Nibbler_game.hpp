/*
** EPITECH PROJECT, 2023
** B-OOP-400-PAR-4-1-arcade-titien.carellas
** File description:
** Nibbler.hpp
*/
/**
 * @file Nibbler.hpp
 * @brief Nibbler class declaration used to manage the game Nibbler
 * @brief Nibbler is a classic arcade game developed and released by Rock-Ola in 1982. It is a simple game where the player controls a snake-like creature, known as the Nibbler, that moves around a maze-like area collecting food pellets while avoiding obstacles and its own tail. As the Nibbler eats more food, its tail grows longer, making the game progressively more challenging. The game was popular in the 1980s and has since become a cult classic among retro gaming enthusiasts.
 */
#ifndef SNAKE_HPP_
    #define SNAKE_HPP_

#include "../IGames.hpp"

/**
 * @class Nibbler
 * @brief Nibbler class used to manage the game Nibbler
 */
class Nibbler : public IGames{
public:
	/**
	 *@brief Construct
	 *@fn Nibbler()
	 */
    Nibbler();
	/**
	 * @brief Construct
	 * @fn Nibbler(int x, int y)
	 * @param x X position
	 * @param y Y position
	 */
    Nibbler(int x, int y);
	/**
	 * @brief Destroy
	 * @fn ~Nibbler()
	 */
    ~Nibbler();
	/**
	 * @brief Init the game Nibbler (load the map, the snake, the food, the texts)
	 * @fn void init()
	 */
    virtual void init();
	/**
	 * @brief Init the texts of the game Nibbler (score, highscore, level) @ref _string
	 * @fn void initTexts()
	 */
	virtual void initTexts();
	/**
	 * @brief Update the game Nibbler (update the snake, the food, the texts) based on the key pressed
	 * @fn bool update(int key)
	 */
    virtual bool update(int key);
	/**
	 * @brief Load the assets of the game Nibbler (map, snake, food) @ref _assets
	 * @fn std::vector<std::tuple<char, std::string, int>> loadAssets()
	 * @return A vector of tuple containing the character, the path to the asset and the index for the spritesheet
	 */
    virtual std::vector<std::tuple<char, std::string, int>> loadAssets();
	/**
	 * @brief Get the elements of the game Nibbler (map, snake, food) @ref _assets
	 * @fn std::vector<std::tuple<char, Position>> getElements()
	 * @return A vector of tuple containing the character and the position of the element desired
	 */
    virtual std::vector<std::tuple<char, Position>> getElements();
	virtual std::tuple<std::vector<Position>, std::vector<Position>> parse_map(std::string map_name);
    virtual double getScore();
    virtual size_t getSpeed();
    virtual void handleCollision();
    virtual void handleInput(int key);
    virtual bool collisionMap(Position pos);
	virtual void collisionFood();
	virtual std::vector<std::tuple<std::string, Position>> loadTexts();
	virtual void updateTexts();
	virtual std::vector<std::string>writeScore();
	virtual std::vector<std::string> readScore();
	virtual void readConfig();
	/**
	 * @brief Get the remaining time of the game Nibbler
	 * @fn double getRemainingTime()
	 * @return The remaining time
	 */
	double getRemainingTime();
	/**
	 *  @brief Check if the time is over or not @ref getRemainingTime()
	 *  @fn bool TimeOut()
	 *  @return True if the time is over, false otherwise
	 */
	bool TimeOut();
	/**
	 * @brief Get the index of the string in the vector @ref _string
	 * @fn int getIndexString(std::string)
	 * @param str The string to find
	 * @return The index of the string in the vector
	 */
	int getIndexString(std::string);
	/**
	 * @brief Add time to the game Nibbler (used to increase the time when the player eats a food)
	 * @fn void addTime(int time)
	 * @param time The time to add
	 */
	void addTime(int time);
	/**
	 * @brief Get the login of the player
	 * @fn std::string getLogin()
	 * @return The login of the player (used to save the highscore) @ref _highscore it will use the name of the user session 
	 */
	std::string getLogin();
	/**
	 * void autoMove(Position &pos)
	 * @brief Move the snake automatically if the player doesn't press any key it will check if the snake can move to the left, right, up or down
	 */
	void autoMove(Position &pos);
protected:
	bool HighScoreIsSet = false;
	size_t _skinMultiplier = 0;
	size_t _speed = 250;
    size_t _score = 0;
    size_t _highScore = 0;
	size_t _level = 1;
	std::vector<Food*> _food;
    Map* _map;
    PlayerS* _snake;
    std::vector<std::tuple<std::string, Position>> _string;
    std::chrono::time_point<std::chrono::high_resolution_clock> _clock_start;
    std::chrono::time_point<std::chrono::high_resolution_clock> _clock_end;
	HighScore* _highscore;
	std::vector<std::pair<std::string, std::string>> _configData;

private:
};

#endif /*SNAKE_HPP_*/