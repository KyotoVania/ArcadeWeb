/*
** EPITECH PROJECT, 2023
** B-OOP-400-PAR-4-1-arcade-titien.carellas
** File description:
** Nibbler.cpp
*/


#include "Nibbler_game.hpp"
#include <algorithm>

extern "C" IGames *create()
{
	return new Nibbler();
}

extern "C" std::string getName()
{
	return "Nibbler";
}

extern "C" void destroy(IGames *game)
{
	delete game;
}

extern "C" IGames *createGameInstance()
{
    return new Nibbler();
}

Nibbler::Nibbler()
{
	init();
}

Nibbler::~Nibbler()
{
}
void Nibbler::readConfig()
{

    std::ifstream file("configure/game.conf");
    std::string line;
    std::string name;
    std::string value;
    int i = 0;

    if (file.is_open()) {
        while (getline(file, line)) {
            name = line.substr(0, line.find(":"));
            value = line.substr(line.find(":") + 1, line.size());
            _configData.push_back(std::pair(name, value));
            i++;
        }
    }
    file.close();

    for (auto& asset : _configData) {
        if (std::get<0>(asset) == "Skin")
			_skinMultiplier = std::stoi(std::get<1>(asset));
    }
}

void Nibbler::init()
{
	//init snake
	readConfig();
	std::string levelName =  std::to_string(_level);
	levelName += ".levels";
	std::tuple<std::vector<Position>, std::vector<Position>> pos_map_foods = parse_map(levelName);
	
	_snake = new PlayerS(9,9); // TODO: snake is supposed to be at the bottom of the map (nibbler will be at the bottom).
	_snake->setRotation(RIGHT);
	//init the vector of food with the positions of the food get by the parser
	for (auto& pos : std::get<1>(pos_map_foods)) {
		_food.push_back(new Food(pos.getX(), pos.getY()));
	}//init map
	_map = new Map(std::get<0>(pos_map_foods));
	_score = 0;
	//test purpose the cell is not in the snake
	_score = 350; // magic value for testing purpose
	_clock_start = std::chrono::high_resolution_clock::now();
	_clock_end = std::chrono::high_resolution_clock::now();
	initTexts();
}

void Nibbler::initTexts()
{
    _string.push_back(std::make_tuple("Score: " + std::to_string(_score), Position(300, 100)));
	_string.push_back(std::make_tuple("Time: " + std::to_string(990), Position(300, 0)));
	_string.push_back(std::make_tuple("Highscore: " + std::to_string(_highScore), Position(650, 100)));
	_string.push_back(std::make_tuple("Level: " + std::to_string(_level), Position(650, 0)));
}

std::vector<std::tuple<char, std::string, int>> Nibbler::loadAssets()
{
    std::vector<std::tuple<char, std::string, int>> assetsToSend;

    assetsToSend.push_back(std::make_tuple('H', "fullRessource.png", 0 + (_skinMultiplier * 8)));//head
    assetsToSend.push_back(std::make_tuple('I', "fullRessource.png", 4 + (_skinMultiplier * 8)));//body
    assetsToSend.push_back(std::make_tuple('*', "fullRessource.png", 5 + (_skinMultiplier * 8)));//food
    assetsToSend.push_back(std::make_tuple('M', "fullRessource.png", 7 + (_skinMultiplier * 8)));//map
    return assetsToSend;
}

std::vector<std::tuple<std::string, Position>> Nibbler::loadTexts()
{
	return _string;
}

std::vector<std::tuple<char, Position>> Nibbler::getElements()
{
    std::vector<std::tuple<char, Position>> elements;
    elements.push_back(std::make_tuple('H', _snake->getHeadPos()));
	for (size_t i = 1; i < _snake->getSize(); i++) {
	    elements.push_back(std::make_tuple('I', _snake->getBodyPos(i)));
	}
	for (size_t i = 0; i < _map->getMap().size(); i++) {
		elements.push_back(std::make_tuple('M', _map->getPosition(i)));
	}
	for (size_t i = 0; i < _food.size(); i++) {
		elements.push_back(std::make_tuple('*', _food[i]->getPos()));
	}
	return elements;
}

bool Nibbler::collisionMap(Position pos)
{
	//in nbbler if the snake touch the wall it doesn't die but it can't go through the wall so it's like a collision
	for (size_t i = 0; i < _map->getMap().size(); i++) {
		if (pos.getX() == _map->getPosition(i).getX() && pos.getY() == _map->getPosition(i).getY()){
			return true;
		}
	}
	return false;
}

void Nibbler::addTime(int time)
{
	_clock_start += std::chrono::milliseconds(time);
}

void Nibbler::collisionFood()
{
	for (size_t i = 0; i < _food.size(); i++) {
		if (_food[i]->checkCollision(_snake->getHeadPos())) {
			//add cell to snake
			std::pair<int, int> pos = _food[i]->respawn(_map->getPositionsVector(), _snake->getSnakePosVector(), _snake->getSnakeTailPosVector());
			_food[i]->setPos(pos.first, pos.second);
			_snake->grow();
			_food.erase(_food.begin() + i);
			_score += 5;
			//check if time was modified with print
			addTime(2500);
		}
	}
	if (_food.size() == 0)
	{
		addTime(5000);
		_level += 1;
		//delete map and load new one
		std::string levelName =  std::to_string(_level);
		levelName += ".levels";
		std::tuple<std::vector<Position>, std::vector<Position>> pos_map_foods = parse_map(levelName);
		_map = new Map(std::get<0>(pos_map_foods));
		for (auto& pos : std::get<1>(pos_map_foods)) {
			_food.push_back(new Food(pos.getX(), pos.getY()));
		}
		//need to put the snake at the botoom left of the map
		_snake->RespawnAt(Position(2, 15));
		_snake->setRotation(RIGHT);
		if (_level >= 6)
            _level = 1;
	}
}

void Nibbler::handleCollision()
{
	collisionFood();
	if (collisionMap(_snake->getHeadPos()))
	{
		//this is not to bad but it's not the best way to do it cause there is still sometime a frame looging sus + it should check if the position doesnt belong to the snake to
		Position pos_tmp(_snake->getHeadPos().getX(), _snake->getHeadPos().getY());
		direction_t dir = _snake->getRotation();
		if (dir == RIGHT || dir == LEFT) {
			if (dir == RIGHT)
				pos_tmp.setX(pos_tmp.getX() - 1);
			else
				pos_tmp.setX(pos_tmp.getX() + 1);
			pos_tmp.setY(pos_tmp.getY() - 1);
			if (collisionMap(pos_tmp) == false )
			{
				_snake->setRotation(UP);
			} else {
				pos_tmp.setY(pos_tmp.getY() + 2);
				_snake->setRotation(DOWN);
			}
		} else if (dir == UP || dir == DOWN) {
			if (dir == UP)
				pos_tmp.setY(pos_tmp.getY() + 1);
			else
				pos_tmp.setY(pos_tmp.getY() - 1);
			pos_tmp.setX(pos_tmp.getX() - 1);
			if (collisionMap(pos_tmp) == false){
				_snake->setRotation(LEFT);
			}else{
				pos_tmp.setX(pos_tmp.getX() + 2);
				_snake->setRotation(RIGHT);
			}
		}
		_snake->move(pos_tmp);
	}
}


bool Nibbler::update(int key)
{
	handleInput(key);
	handleCollision();
	if (TimeOut() || _snake->checkEatHimself()) {
        return false;
    }
	return true;
}

bool Nibbler::TimeOut()
{
	if (getRemainingTime() <= 0)
        return true;
	return false;
}

int Nibbler::getIndexString(std::string str)
{
    //check in the vector _string (containning a tuple (the string is the first position)) if there is a string that match the one received as parameter
	//if there is a match return the index of the string in the vector
	for (size_t i = 0; i < _string.size(); i++)
	{
		//compare the string received as parameter with the string in the vector
		if (str.compare(std::get<0>(_string[i])) == 0)
			return i;
	}
    return -1;
}

void Nibbler::updateTexts()
{

	std::string str = "Score: " + std::to_string((int)_score);
	std::string str2 = "Time: " + std::to_string(getRemainingTime());

	_string[0] = std::make_tuple(str, Position(300, 100));
	_string[1] = std::make_tuple(str2, Position(300, 0));
	_string[2] = std::make_tuple("Highscore: " + std::to_string(_highScore), Position(650, 100));
	_string[3] = std::make_tuple("Level: " + std::to_string(_level), Position(650, 0));
}



double Nibbler::getRemainingTime()
{
    //990 is the starting time we just need to decrease it by the time elapsed witch is _clock_start
	//minus the time clock stazrt and end
	_clock_end = std::chrono::high_resolution_clock::now();
	std::chrono::duration<double> elapsed_seconds = _clock_end - _clock_start;
	double timeRemaining = 9000/1000 - elapsed_seconds.count();
	if (timeRemaining < 0.0)
        timeRemaining = 0;
	return timeRemaining;
}

double Nibbler::getScore()
{
	return _score;
}

size_t Nibbler::getSpeed()
{
    return _speed;
}

void Nibbler::handleInput(int key)
{
    Position position_tmp(_snake->getHeadPos().getX(), _snake->getHeadPos().getY());
    bool keyPressed = true;
	direction_t dir_tmp = _snake->getRotation();
    if (key == 25 ) {
        // Move up
        if (_snake->getRotation() != direction_t::DOWN) {
            position_tmp.setY(position_tmp.getY() - 1);
			if (collisionMap(position_tmp) == false)
			    _snake->setRotation(UP);
		}
		else
			keyPressed = false;
    } else if (key == 18) {
        // Move down
        if (_snake->getRotation() != direction_t::UP) {
            position_tmp.setY(position_tmp.getY() + 1);
			if (collisionMap(position_tmp) == false)
                _snake->setRotation(DOWN);
		}
		else 
			keyPressed = false;	
    } else if (key == 3 ) {
        // Move right
        if (_snake->getRotation() != direction_t::LEFT) {
            position_tmp.setX(position_tmp.getX() + 1);
			_snake->setRotation(RIGHT);
		}
		else 
			keyPressed = false;
    } else if (key == 16) {
        // Move left
        if (_snake->getRotation() != direction_t::RIGHT) {
            position_tmp.setX(position_tmp.getX() - 1);
			_snake->setRotation(LEFT);
        }
		else 
			keyPressed = false;
    } else {
        keyPressed = false;
    }
    if (keyPressed && (collisionMap(position_tmp) == true || _snake->checkCollision(position_tmp))) {
        position_tmp = _snake->getHeadPos();
		keyPressed = false;
		_snake->setRotation(dir_tmp);
    }
    if (!keyPressed) {
        autoMove(position_tmp);
    }
    _snake->move(position_tmp);
}

void Nibbler::autoMove(Position& position_tmp)
{
    Position next_position = position_tmp;

    if (_snake->getRotation() == direction_t::UP) {
        next_position.setY(next_position.getY() - 1);
    } else if (_snake->getRotation() == direction_t::RIGHT) {
        next_position.setX(next_position.getX() + 1);
    } else if (_snake->getRotation() == direction_t::DOWN) {
        next_position.setY(next_position.getY() + 1);
    } else if (_snake->getRotation() == direction_t::LEFT) {
        next_position.setX(next_position.getX() - 1);
    }

    if (collisionMap(next_position)) {
        // Handle wall collision here
        direction_t dir = _snake->getRotation();
        if (dir == RIGHT || dir == LEFT) {
            if (dir == RIGHT) {
                next_position.setX(next_position.getX() - 1);
            } else {
                next_position.setX(next_position.getX() + 1);
            }
            next_position.setY(next_position.getY() - 1);
            if (collisionMap(next_position) == false) {
                _snake->setRotation(UP);
            } else {
                next_position.setY(next_position.getY() + 2);
                _snake->setRotation(DOWN);
            }
        } else if (dir == UP || dir == DOWN) {
            if (dir == UP) {
                next_position.setY(next_position.getY() + 1);
            } else {
                next_position.setY(next_position.getY() - 1);
            }
            next_position.setX(next_position.getX() - 1);
            if (collisionMap(next_position) == false) {
                _snake->setRotation(LEFT);
            } else {
                next_position.setX(next_position.getX() + 2);
                _snake->setRotation(RIGHT);
            }
        }
    }
    position_tmp = next_position;
    
}


std::tuple<std::vector <Position>, std::vector < Position > > Nibbler::parse_map(std::string map_name)
{
	std::vector <Position> walls;
	std::vector <Position> food;
	std::ifstream file;
	std::string line;
	int x = 0;
	int y = 0;

	file.open("Levels/" + map_name);
	if (!file.is_open()) {
		std::cout << "file not opened" << std::endl;
		throw std::exception();
	}
	while (std::getline(file, line)) {
		for (auto &i : line) {
			if (i == 'W') {
				walls.push_back(Position(x, y));
			}
			else if (i == 'F') {
				food.push_back(Position(x, y));
			}
			x++;
		}
		x = 0;
		y++;
	}
	file.close();
	return std::make_tuple(walls, food);
}

std::vector<std::string> Nibbler::writeScore()
{
	HighScoreIsSet = true;
	return _highscore->writeScore("Nibbler", _score); 
}

std::vector<std::string> Nibbler::readScore()
{
	if (HighScoreIsSet == false)
		return writeScore();
	
    return _highscore->readScore("Nibbler");
}
