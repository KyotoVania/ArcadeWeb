/*
** EPITECH PROJECT, 2023
** B-OOP-400-PAR-4-1-arcade-titien.carellas
** File description:
** Position.hpp
*/
/**
 * @file Position.hpp
 * @brief Position class declaration used to store the position of an object
 */

#ifndef POSITION_HPP_
	#define POSITION_HPP_

#include <tuple>
/**
 * @brief Enum used to store the direction of an object used for the rotation in the graphic and the movement in the game
 */
enum direction_t
{
	UP,
	DOWN,
	LEFT,
	RIGHT,
	NONE
};

/**
 * @class Position
 * @brief Position class used to store the position of an object
 */
class Position
{
	public:
	/**
	 * @brief Construct
	 * @fn Position()
	 */
	Position();
	/**
	 * @brief Construct
	 * @fn Position(int x, int y)
	 * @param x X position
	 * @param y Y position
	 */
	Position(int x, int y);
	/**
	 * @brief Construct
	 * @fn Position(int x, int y, direction_t dir)
	 * @param x X position
	 * @param y Y position
	 * @param dir Direction of the object
	 */
	Position(int x, int y, direction_t dir);
	/**
	 * @brief Destroy
	 * @fn ~Position()
	 */
	~Position();
	/**
	 * @brief Get the position
	 * @fn std::tuple<int, int> getPos()
	 * @return std::tuple<int, int> Position
	 */
	std::tuple<int, int> getPos();
	/**
	 * @brief Get the position
	 * @fn std::pair<int, int> getPosPair()
	 * @return std::pair<int, int> Position
	 */
	std::pair<int, int> getPosPair();
	/**
	 * @brief Set the X position
	 * @fn void setX(int x)
	 * @param x X position
	 */
	void setX(int x);
	/**
	 * @brief Set the Y position
	 * @fn void setY(int y)
	 * @param y Y position
	 */
	void setY(int y);
	/**
	 * @brief Set the position
	 * @fn void setPos(int x, int y)
	 * @param x X position
	 * @param y Y position
	 */
	int getX();
	/**
	 * @brief Get the Y position
	 * @fn int getY()
	 * @return int Y position
	 */
	int getY();
	/**
	 * @brief Get the direction
	 * @fn direction_t getRotation()
	 * @return direction_t Direction
	 */
	direction_t getRotation();
	/**
	 * @brief Set the direction
	 * @fn void setRotation(direction_t dir)
	 * @param dir Direction
	 */
	void setRotation(direction_t dir);
	/**
	 * @brief X position
	 */
	int _x;
	/**
	 * @brief Y position
	 */
	int _y;
	/**
	 * @brief Direction
	 */
	direction_t _rotation;
};

#endif /*POSITION_HPP_*/