/*
** EPITECH PROJECT, 2023
** B-OOP-400-PAR-4-1-arcade-titien.carellas
** File description:
** Position.hpp
*/

#include "Position.hpp"
#include <iostream>

Position::Position()
{
    _x = 0;
    _y = 0;
    _rotation = direction_t::NONE;
}

Position::Position(int x, int y)
{
    _x = x;
    _y = y;
    _rotation = direction_t::NONE;
}

Position::Position(int x, int y, direction_t dir)
{
    _x = x;
    _y = y;
    _rotation = dir;
}

Position::~Position()
{
}

std::tuple<int, int> Position::getPos()
{
	std::tuple<int, int> pos = std::make_tuple(_x, _y);
    return pos;
}

std::pair<int, int> Position::getPosPair()
{
    std::pair<int, int> pos = std::make_pair(_x, _y);
    return pos;
}

void Position::setX(int x)
{
    _x = x;
}

void Position::setY(int y)
{
    _y = y;
}

int Position::getX()
{
    return _x;
}

int Position::getY()
{
    return _y;
}


direction_t Position::getRotation()
{
    return _rotation;
}

void Position::setRotation(direction_t dir)
{
    _rotation = dir;
}